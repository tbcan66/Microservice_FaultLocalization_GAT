import json
import re
from pathlib import Path
from collections import defaultdict
import graph_common as gc

# Mirror of the Level 2 constant — guards method_def regex false-positives
_SKIP_METHOD_NAMES = {'ok', 'of', 'get', 'set', 'is', 'as', 'by', 'on', 'to'}

class MethodGraphExtractor:
    def __init__(self):
        self.root_path = Path(gc.TRAIN_TICKET_PATH)
        self.services = gc.discover_services(self.root_path)
        
        # Graph Data
        self.nodes = [] # {id, label, type, service, ...}
        self.edges = [] # {source, target, relation, type}
        self._seen_edges = set()  # FIX 3: deduplication
        
        # Lookups
        self.method_id_to_node = {} 
        self.interface_to_impl_map = {}
        self.repository_to_node = {}

    def extract(self):
        print("\n🔍 Extracting Level 3 (Method) Graph...")
        
        # 1. Discovery Phase
        self._extract_all_methods()
        self._extract_repositories()
        
        # 2. Linking Phase
        self._link_methods()
        
        # 3. Save
        self._save_results()

    def _extract_all_methods(self):
        print("  Scanning Method Nodes (Java, Polyglot)...")
        for service in self.services:
            src_path = self.root_path / service
            if not src_path.exists(): continue
            
            # 1. Java Methods
            for java_file in src_path.rglob("*.java"):
                # FIX 2: exclude test directories — they add spurious mock/stub method nodes
                if 'test' in java_file.parts:
                    continue
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    class_name = java_file.stem
                    
                    # Capture Interface implementations for linking
                    if "ServiceImpl" in class_name:
                         iname = class_name.replace("Impl", "")
                         self.interface_to_impl_map[f"{service}:{iname}"] = f"{service}:{class_name}"
                         
                    # Capture Feign Clients for linking
                    feign_match = gc.PATTERNS['feign_client'].search(content)
                    if feign_match:
                         # Treat Feign Interface as "Service"
                         target_service = feign_match.group(1)
                         self.interface_to_impl_map[f"{service}:{class_name}"] = f"FEIGN:{target_service}"

                    for match in gc.PATTERNS['method_def'].finditer(content):
                        m_name = match.group(1)
                        if m_name in ['toString', 'hashCode', 'equals']: continue
                        
                        node_id = f"{service}:{class_name}.{m_name}"
                        # FIX 1: guard against duplicates (mirrors Python branch behaviour)
                        if node_id not in self.method_id_to_node:
                            is_api = "@RequestMapping" in content or "@GetMapping" in content or "@PostMapping" in content
                            self.nodes.append({
                                "id": node_id,
                                "label": f"{class_name}.{m_name}",
                                "service": service,
                                "type": "METHOD",
                                "info": "Controller" if is_api else "Internal"
                            })
                            self.method_id_to_node[node_id] = node_id
                except: pass

            # 2. Python Functions
            for py_file in src_path.rglob("*.py"):
                try:
                    with open(py_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    
                    # Method 1: Tornado Routes
                    for match in gc.PATTERNS['py_tornado_route'].finditer(content):
                        handler = match.group(2)
                        node_id = f"{service}:{handler}"
                        if node_id not in self.method_id_to_node:
                             self.nodes.append({"id": node_id, "label": handler, "service": service, "type": "METHOD", "language": "python"})
                             self.method_id_to_node[node_id] = node_id

                    # Method 2: Standard Defs
                    for match in gc.PATTERNS['python_def'].finditer(content):
                        func_name = match.group(1)
                        if func_name.startswith('__'): continue
                        node_id = f"{service}:{func_name}"
                        if node_id not in self.method_id_to_node:
                             self.nodes.append({"id": node_id, "label": func_name, "service": service, "type": "METHOD", "language": "python"})
                             self.method_id_to_node[node_id] = node_id
                except: pass

    def _extract_repositories(self):
        print("  Scanning Repositories...")
        for service in self.services:
            src_path = self.root_path / service
            for java_file in src_path.rglob("*.java"):
                # FIX 2: consistent with _extract_all_methods and _link_methods
                if 'test' in java_file.parts:
                    continue
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    match = gc.PATTERNS['repository_def'].search(content)
                    if match:
                        repo_name = match.group(1)
                        node_id = f"{service}:{repo_name}"
                        if repo_name not in self.repository_to_node:  # dedup
                            self.nodes.append({"id": node_id, "label": repo_name, "service": service, "type": "REPOSITORY"})
                            self.repository_to_node[repo_name] = node_id
                except: pass

    def _link_methods(self):
        print("  Linking Methods...")
        for service in self.services:
            src_path = self.root_path / service
            for java_file in src_path.rglob("*.java"):
                # FIX 2: exclude test directories from linking too
                if 'test' in java_file.parts:
                    continue
                self._scan_java_file_links(java_file, service)

    def _scan_java_file_links(self, file_path, service):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f: lines = f.readlines()
            content_str = "".join(lines)
            field_map = {m.group(2): m.group(1) for m in gc.PATTERNS['field_injection'].finditer(content_str)}
            class_name = file_path.stem
            current_method = None
            
            for line in lines:
                m_match = gc.PATTERNS['method_def'].search(line)
                # FIX 1: same guard as Level 2 — skip utility/constructor names,
                # and do NOT continue so the same line is scanned for calls too.
                if m_match:
                    name = m_match.group(1)
                    if name[0].islower() and len(name) > 2 and name not in _SKIP_METHOD_NAMES:
                        current_method = name
                # NOTE: no 'continue' — method signature line may also call super/this
                
                if current_method:
                    source_id = f"{service}:{class_name}.{current_method}"
                    
                    # 1. Check Method Calls (obj.method())
                    for call in gc.PATTERNS['method_call'].finditer(line):
                        var, method = call.groups()
                        if var in field_map:
                            type_name = field_map[var]
                            
                            # Repository Call
                            if "Repository" in type_name:
                                target = self.repository_to_node.get(type_name, f"{service}:{type_name}")
                                self._add_edge(source_id, target, "CALLS_REPO", "METHOD_TO_REPO")
                            
                            # Service/Component Call
                            else:
                                if f"{service}:{type_name}" in self.interface_to_impl_map:
                                    mapping = self.interface_to_impl_map[f"{service}:{type_name}"]
                                    if mapping.startswith("FEIGN:"):
                                         # Feign Call - Link to Proxy Interface Method
                                         # In Level 3, we treat the Feign Interface Method as the node
                                         target_class = type_name
                                    else:
                                         # Standard Impl
                                         target_class = mapping.split(":")[1]
                                    
                                    target = f"{service}:{target_class}.{method}"
                                    self._add_edge(source_id, target, "CALLS", "METHOD_TO_METHOD")

                    # 2. Check Local Calls (method())
                    for lc in gc.PATTERNS['local_method_call'].finditer(line):
                        m = lc.group(1)
                        if m not in ['if','for','while','return','catch']:
                            target = f"{service}:{class_name}.{m}"
                            if target != source_id:
                                self._add_edge(source_id, target, "CALLS_LOCAL", "METHOD_TO_METHOD")

        except Exception: pass

    def _add_edge(self, source, target, rel, type_):
        # FIX 3: deduplicate — same edge can appear multiple times if a method
        # is called more than once inside the same caller
        key = (source, target, rel)
        if key not in self._seen_edges:
            self._seen_edges.add(key)
            self.edges.append({"source": source, "target": target, "relation": rel, "type": type_})

    def _save_results(self):
        output_path = Path("output/level3_method_graph.json")
        output_path.parent.mkdir(exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump({"nodes": self.nodes, "links": self.edges}, f, indent=2)
            
        print(f"✅ Saved Level 3 Method Graph: {len(self.nodes)} Nodes, {len(self.edges)} Edges")
        
        # FIX 4: corrected stats (old formula counted every node since all use ':' in ID)
        method_nodes = [n for n in self.nodes if n.get('type') == 'METHOD']
        repo_nodes   = [n for n in self.nodes if n.get('type') == 'REPOSITORY']
        py_nodes     = [n for n in method_nodes if n.get('language') == 'python']
        print(f"  - Method nodes (Java): {len(method_nodes) - len(py_nodes)}")
        print(f"  - Method nodes (Python): {len(py_nodes)}")
        print(f"  - Repository nodes: {len(repo_nodes)}")
        print(f"  - Total edges: {len(self.edges)}")

if __name__ == "__main__":
    extractor = MethodGraphExtractor()
    extractor.extract()
