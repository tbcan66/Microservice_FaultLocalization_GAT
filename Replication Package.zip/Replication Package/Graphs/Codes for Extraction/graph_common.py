import os
import re
from pathlib import Path

# Configuration
TRAIN_TICKET_PATH = "User_Path/train-ticket-with-test-suites-1.0.0"

# Path to Service Mapping
PATH_TO_SERVICE = {
    "/api/v1/adminrouteservice": "ts-admin-route-service",
    "/api/v1/admintravelservice": "ts-admin-travel-service",
    "/api/v1/adminuserservice": "ts-admin-user-service",
    "/api/v1/adminbasicservice": "ts-admin-basic-service",
    "/api/v1/adminorderservice": "ts-admin-order-service",
    "/api/v1/assuranceservice": "ts-assurance-service",
    "/api/v1/auth": "ts-auth-service",
    "/api/v1/users": "ts-auth-service",
    "/api/v1/avatar": "ts-avatar-service",
    "/api/v1/basicservice": "ts-basic-service",
    "/api/v1/cancelservice": "ts-cancel-service",
    "/api/v1/configservice": "ts-config-service",
    "/api/v1/consignpriceservice": "ts-consign-price-service",
    "/api/v1/consignservice": "ts-consign-service",
    "/api/v1/contactservice": "ts-contacts-service",
    "/api/v1/deliveryservice": "ts-delivery-service",
    "/api/v1/executeservice": "ts-execute-service",
    "/api/v1/fooddeliveryservice": "ts-food-delivery-service",
    "/api/v1/foodmapservice": "ts-food-map-service",
    "/api/v1/foodservice": "ts-food-service",
    "/api/v1/gateway": "ts-gateway-service",
    "/api/v1/inside_pay_service": "ts-inside-payment-service",
    "/api/v1/newsservice": "ts-news-service",
    "/api/v1/notifyservice": "ts-notification-service",
    "/api/v1/orderOtherService": "ts-order-other-service",
    "/api/v1/orderservice": "ts-order-service",
    "/api/v1/paymentservice": "ts-payment-service",
    "/api/v1/preserveotherservice": "ts-preserve-other-service",
    "/api/v1/preserveservice": "ts-preserve-service",
    "/api/v1/priceservice": "ts-price-service",
    "/api/v1/rebookservice": "ts-rebook-service",
    "/api/v1/routeplanservice": "ts-route-plan-service",
    "/api/v1/routeservice": "ts-route-service",
    "/api/v1/seatservice": "ts-seat-service",
    "/api/v1/securityservice": "ts-security-service",
    "/api/v1/stationfoodservice": "ts-station-food-service",
    "/api/v1/stationservice": "ts-station-service",
    "/api/v1/ticketoffice": "ts-ticket-office-service",
    "/api/v1/ticketinfoservice": "ts-ticketinfo-service",
    "/api/v1/trainfoodservice": "ts-train-food-service",
    "/api/v1/trainservice": "ts-train-service",
    "/api/v1/travelplanservice": "ts-travel-plan-service",
    "/api/v1/travelservice": "ts-travel-service",
    "/api/v1/travel2service": "ts-travel2-service",
    "/api/v1/ui": "ts-ui-dashboard",
    "/api/v1/userservice": "ts-user-service",
    "/api/v1/verifycode": "ts-verification-code-service",
    "/api/v1/voucherservice": "ts-voucher-service",
    "/api/v1/waitorderservice": "ts-wait-order-service",
}

# Regex Patterns
PATTERNS = {
    # Direct service names
    'service_name_quoted': re.compile(r'["\']([tT][sS]-[a-zA-Z0-9-]+)["\']'),

    # @Value default hostname: @Value("${ts.x.service.url:ts-order-service}")
    # Captures the default value (after ':') when it looks like a ts-service hostname
    'value_default_hostname': re.compile(r'@Value\s*\(["\']\$\{[^}]+:(ts-[a-z0-9-]+)\}["\']\)'),
    
    # HTTP calls
    'http_url': re.compile(r'["\']https?://([a-zA-Z0-9-]+)[:\d]*(/[^"\']*)?["\']'),

    # YAML/Config calls
    'yaml_http_url': re.compile(r'https?://([a-zA-Z0-9-]+)'),
    
    # Nginx Proxy
    'nginx_backend': re.compile(r'set\s+\$backend\s+(ts-[a-zA-Z0-9-]+);'),

    # API paths in code
    'api_path': re.compile(r'["\'](/api/v1/[a-zA-Z0-9/_-]+)["\']'),
    
    # Polyglot Patterns (Go, Python, JS)
    'go_http': re.compile(r'http\.(?:Get|Post|NewRequest)\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE),
    'python_requests': re.compile(r'requests\.(?:get|post|put|delete)\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE),
    'js_fetch': re.compile(r'(?:fetch|\$.ajax|axios\.[a-z]+)\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE),
    
    # API Definition Patterns
    'rest_controller': re.compile(r'@RestController', re.MULTILINE),
    'service_annotation': re.compile(r'@Service', re.MULTILINE),
    'feign_client': re.compile(r'@FeignClient\s*\(\s*(?:name\s*=\s*|value\s*=\s*)?["\'](ts-[a-zA-Z0-9-]+)["\']', re.MULTILINE),
    'repository_def': re.compile(r'public\s+interface\s+(\w+)\s+extends\s+(?:MongoRepository|JpaRepository|CrudRepository)', re.MULTILINE),
    
    'class_mapping': re.compile(r'@RequestMapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?["\']([^"\']+)["\']', re.MULTILINE),
    'method_mapping': re.compile(r'@(Get|Post|Put|Delete|Patch|Request)Mapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?["\']([^"\']+)["\']', re.MULTILINE),
    
    # Polyglot API Definitions
    'py_tornado_route': re.compile(r'\(\s*r?["\']([^"\']+)["\']\s*,\s*([a-zA-Z0-9_]+)\s*\)'),
    'js_express_route': re.compile(r'router\.(get|post|put|delete)\s*\(\s*["\']([^"\']+)["\']'),
    'go_http_route': re.compile(r'http\.HandleFunc\s*\(\s*["\']([^"\']+)["\']'),

    # Internal Method Patterns
    # Java: Optional visibility, return type, method name, open parenthesis
    'method_def': re.compile(r'(?:(?:public|private|protected)\s+)?(?:[\w<>\[\]?]+\s+)+([a-zA-Z0-9_]+)\s*\('),
    'python_def': re.compile(r'def\s+([a-zA-Z0-9_]+)\s*\('),
    'method_call': re.compile(r'(\w+)\.([a-zA-Z0-9_]+)\('),
    'local_method_call': re.compile(r'\s+([a-zA-Z0-9_]+)\('),
    
    # UI AJax Patterns (Specific)
    'ui_ajax_url': re.compile(r'url:\s*["\']([^"\']+)["\']'),
    'ui_axios_url': re.compile(r'(?:get|post|put|delete)\(\s*["\']([^"\']+)["\']'),
    
    # Field Injection — matches both:
    #   private CancelService cancelService;
    #   @Autowired\n    CancelService cancelService;  (no private modifier)
    'field_injection': re.compile(r'(?:private\s+)?([A-Z]\w+)\s+([a-z]\w+)\s*;'),
}

def discover_services(root_path_str: str):
    """Find all service directories in the given root path."""
    root_path = Path(root_path_str)
    services = set()
    print("📦 Discovering services...")
    
    for item in root_path.iterdir():
        if item.is_dir() and item.name.startswith('ts-'):
            has_code = any([
                (item / 'src').exists(),
                (item / 'pom.xml').exists(),
                (item / 'package.json').exists(),
                (item / 'Dockerfile').exists(),
                (item / 'app.js').exists(),
                (item / 'main.py').exists()
            ])
            if has_code:
                services.add(item.name)
                # print(f"  ✓ {item.name}")
    
    print(f"  Total: {len(services)} services found")
    return sorted(list(services))

def normalize_path(base, method):
    """Combines class-level and method-level paths."""
    if base and not base.startswith('/'): base = '/' + base
    if method and not method.startswith('/'): method = '/' + method
    
    combined = (base + method).replace('//', '/')
    if not combined.startswith('/'): combined = '/' + combined
    return combined
