import json
from pathlib import Path
from collections import defaultdict
import graph_common as gc

class ServiceGraphExtractor:
    def __init__(self):
        self.root_path = Path(gc.TRAIN_TICKET_PATH)
        self.services = gc.discover_services(self.root_path)
        self.edges = set() # (source, target) tuples

    def extract(self):
        print("\n🔍 Extracting Level 1 Service Graph...")
        
        for service in self.services:
            self._scan_service_dependencies(service)
            if service == "ts-ui-dashboard":
                self._scan_ui_dependencies(service)
        
        self._scan_nginx_config()
            
        self._save_results()

    def _scan_ui_dependencies(self, service_name):
        """Scans ts-ui-dashboard for calls."""
        service_path = self.root_path / service_name
        js_path = service_path / "static" / "assets" / "js"
        if not js_path.exists(): js_path = service_path
        
        for js_file in js_path.rglob("*.js"):
            if "node_modules" in str(js_file) or ".min.js" in str(js_file): continue
            try:
                with open(js_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                
                # Check for URLs in AJAX/Axios
                all_urls = gc.PATTERNS['ui_ajax_url'].findall(content) + gc.PATTERNS['ui_axios_url'].findall(content)
                for url in all_urls:
                    # Map URL to Service
                    # 1. Check for direct /api/v1/ prefix mapping
                    target = self._resolve_service_from_path(url)
                    if target and target != service_name:
                        self.edges.add((service_name, target))
                        
            except: pass

    def _scan_service_dependencies(self, service_name):
        """Scans a service for calls to other services."""
        service_path = self.root_path / service_name
        
        # We look for:
        # 1. Direct http://ts-target-service URLs
        # 2. Known API paths mapped to services
        
        # Scan multiple file types for polyglot services
        # Exclude src/test directories to avoid false edges from test stubs and mocks
        extensions = ["*.java", "*.py", "*.js", "*.go", "*.yml", "*.yaml"]
        files = []
        for ext in extensions:
            for f in service_path.rglob(ext):
                # Skip test directories (src/test, test/, tests/)
                parts = f.parts
                if any(p in ('test', 'tests', 'src/test') for p in parts) or \
                   'src/test' in str(f):
                    continue
                files.append(f)
            
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Check 1: HTTP URLs (Code & Config)
                for match in gc.PATTERNS['http_url'].finditer(content):
                    target_host = match.group(1) 
                    if target_host in self.services and target_host != service_name:
                        self.edges.add((service_name, target_host))
                
                # Check 1b: YAML specific URLs (simple http://ts-service)
                if file_path.suffix in ['.yml', '.yaml']:
                     for match in gc.PATTERNS['yaml_http_url'].finditer(content):
                        target_host = match.group(1)
                        if target_host in self.services and target_host != service_name:
                             self.edges.add((service_name, target_host))

                # Check 2: API Paths
                for match in gc.PATTERNS['api_path'].finditer(content):
                    path = match.group(1)
                    target_service = self._resolve_service_from_path(path)
                    if target_service and target_service in self.services and target_service != service_name:
                         self.edges.add((service_name, target_service))
                          
                # Check 3: Quoted Service Names
                for match in gc.PATTERNS['service_name_quoted'].finditer(content):
                    target_name = match.group(1)
                    if target_name in self.services and target_name != service_name:
                         self.edges.add((service_name, target_name))

                # Check 4: Feign Clients
                for match in gc.PATTERNS['feign_client'].finditer(content):
                    target_name = match.group(1)
                    if target_name in self.services and target_name != service_name:
                         self.edges.add((service_name, target_name))

                # Check 5: @Value default hostnames
                # e.g.  @Value("${ts.order.service.url:ts-order-service}")
                # The default value after ':' is the actual hostname used at runtime
                for match in gc.PATTERNS['value_default_hostname'].finditer(content):
                    target_name = match.group(1)
                    if target_name in self.services and target_name != service_name:
                        self.edges.add((service_name, target_name))

            except Exception: pass
            
    def _scan_nginx_config(self):
        """Parse ts-ui-dashboard/nginx.conf for proxy rules.
        Handles both:
          proxy_pass http://ts-service:port;
          set $backend ts-service; proxy_pass http://$backend:port;
        """
        nginx_path = self.root_path / "ts-ui-dashboard" / "nginx.conf"
        if nginx_path.exists():
            try:
                with open(nginx_path, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                # Pattern 1: direct proxy_pass
                for match in gc.PATTERNS['nginx_backend'].finditer(content):
                    target_service = match.group(1)
                    if target_service in self.services:
                         self.edges.add(("ts-ui-dashboard", target_service))
                # Pattern 2: variable-style  set $backend ts-...
                import re
                for match in re.finditer(r'set\s+\$\w+\s+(ts-[a-z0-9-]+)', content):
                    target_service = match.group(1)
                    if target_service in self.services:
                        self.edges.add(("ts-ui-dashboard", target_service))
            except: pass

    def _resolve_service_from_path(self, path):
        """Map /api/v1/foo -> ts-foo-service"""
        # Exact prefix match
        for prefix, svc in gc.PATH_TO_SERVICE.items():
             if path.startswith(prefix):
                 return svc
             # Handle /api/v1/userservice/users scenarios where prefix might be shorter
             if path.startswith(prefix + "/"):
                 return svc
        return None

    def _save_results(self):
        nodes = [{"id": s, "label": s, "type": "SERVICE"} for s in self.services]
        links = []
        for src, tgt in self.edges:
            links.append({
                "source": src,
                "target": tgt,
                "relation": "CALLS",
                "type": "Level 1 Call"
            })
            
        output_path = Path("output/level1_service_graph.json")
        output_path.parent.mkdir(exist_ok=True)
        
        with open(output_path, 'w') as f:
            json.dump({"nodes": nodes, "links": links}, f, indent=2)

        # Stats for User Comparison
        sources = set(src for src, tgt in self.edges)
        targets = set(tgt for src, tgt in self.edges)
        connected = sources.union(targets)
        isolated = set(self.services) - connected
        
        print(f"\n📈 Extraction Stats:")
        print(f"Total services = {len(self.services)}")
        print(f"Services making calls = {len(sources)}")
        print(f"Total call relationships = {len(links)}")
        print(f"Isolated services = {len(isolated)}")
        print(f"Isolated List: {sorted(list(isolated))}")
        print(f"✅ Saved Level 1 Graph to {output_path}")

if __name__ == "__main__":
    extractor = ServiceGraphExtractor()
    extractor.extract()
