import json
import re
from pathlib import Path
from collections import defaultdict
import graph_common as gc

# Method names that are common static-import calls or Java keywords, not real service method definitions.
# Used to guard against method_def regex false-positives (e.g. 'return ok(...)', 'List.of(...)').
_SKIP_METHOD_NAMES = {'ok', 'of', 'get', 'set', 'is', 'as', 'by', 'on', 'to'}

class InterfaceGraphExtractor:
    def __init__(self):
        self.root_path = Path(gc.TRAIN_TICKET_PATH)
        self.services = gc.discover_services(self.root_path)
        
        # Graph Data
        self.nodes = [] # {id, label, type, service, ...}
        self.edges = [] # {source, target, relation, type}
        
        # Lookups
        self.path_to_api_node = {} 
        self.method_id_to_node = {} 
        self.interface_to_impl_map = {}
        self.repository_to_node = {}

    def extract(self):
        print("\n🔍 Extracting Level 2 (API) & Level 3 (Method) Graphs...")
        
        # 1. Discovery Phase
        self._extract_api_nodes()
        self._extract_internal_method_nodes()
        self._extract_feign_clients() # NEW
        self._extract_repository_nodes()
        self._extract_ui_nodes_and_calls()
        
        # 2. Linking Phase
        self._link_api_to_internal()
        self._link_internal_calls()
        self._analyze_external_calls() # Updated for Polyglot
        
        # 3. Synthesis Phase
        self._synthesize_level2_graph()
        
        # 4. Save
        # self._save_level3_graph() # Now handled by extract_method_graph.py

    def _extract_feign_clients(self):
        print("  Scanning Feign Clients...")
        for service in self.services:
            src_path = self.root_path / service
            for java_file in src_path.rglob("*.java"):
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    
                    match = gc.PATTERNS['feign_client'].search(content)
                    if match:
                        target_service = match.group(1)
                        class_name = java_file.stem
                        
                        # Map Interface -> Target Service
                        # Logic: Calling method X on this interface = Calling API on target_service
                        # We need to parse methods to know WHICH api path
                        
                        for m_match in gc.PATTERNS['method_mapping'].finditer(content):
                            verb = m_match.group(1).upper()
                            path = m_match.group(2)
                            
                            # Find the METHOD name associated with this mapping
                            lookahead = content[m_match.end():m_match.end()+200]
                            m_def = gc.PATTERNS['method_def'].search(lookahead)
                            if m_def:
                                method_name = m_def.group(1)
                                node_id = f"{service}:{class_name}.{method_name}"
                                
                                # Create "Proxy Method" Node
                                self.nodes.append({"id": node_id, "label": f"{class_name}.{method_name}", "service": service, "type": "METHOD", "info": "Feign Proxy"})
                                self.interface_to_impl_map[f"{service}:{class_name}"] = f"FEIGN:{target_service}"
                                
                                # Add Edge: Proxy Method -> Target API
                                # We need to resolve the target API node
                                # Issue: We might not know the full path if it uses placeholders, but we try
                                target_api_id = self._resolve_api_node_by_service(target_service, path, verb)
                                if target_api_id:
                                    self._add_edge(node_id, target_api_id, "CALLS_FEIGN", "INTERNAL_TO_API")

                except: pass

    def _resolve_api_node_by_service(self, target_service, path, verb):
        # Precise resolution: Service + Path + Verb
        # normalize path
        path = gc.normalize_path("", path)
        candidates = [n for n in self.nodes if n['service'] == target_service and n['type'] == 'API']
        
        # 1. Exact Match
        for n in candidates:
            if n['path'] == path and n.get('method') == verb: return n['id']
            
        # 2. Path Match (Ignore Verb)
        for n in candidates:
             if n['path'] == path: return n['id']
             
        # 3. Fuzzy
        for n in candidates:
             if path.startswith(n['path']): return n['id']
             
        return None

    def _extract_api_nodes(self):
        print("  Scanning API Nodes (Java, Python, JS, Go)...")
        for service in self.services:
            src_path = self.root_path / service
            if not src_path.exists(): continue
            
            # Scan Java @RestController
            for java_file in src_path.rglob("*.java"):
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    if not gc.PATTERNS['rest_controller'].search(content): continue
                    
                    class_name = java_file.stem
                    class_path = ""
                    cm = gc.PATTERNS['class_mapping'].search(content)
                    if cm: class_path = cm.group(1)
                    
                    for match in gc.PATTERNS['method_mapping'].finditer(content):
                        verb = match.group(1).upper()
                        m_path = match.group(2)
                        full_path = gc.normalize_path(class_path, m_path)
                        self._add_api_node(service, full_path, verb, f"{class_name} (Java)")
                        
                        # Link Controller Method
                        match_end = match.end()
                        lookahead = content[match_end:match_end+500]
                        m_def = gc.PATTERNS['method_def'].search(lookahead)
                        if m_def:
                             key = f"{service}:{class_name}.{m_def.group(1)}"
                             # FIX: must match the service-scoped node_id set in _add_api_node
                             self.method_id_to_node[key] = f"{service}:{verb} {full_path}"
                except: pass

            # Scan Python Tornado
            for py_file in src_path.rglob("*.py"):
                try:
                    with open(py_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    for match in gc.PATTERNS['py_tornado_route'].finditer(content):
                        path = match.group(1)
                        handler = match.group(2)
                        # Assume POST/GET based on handler methods if needed, or generic
                        self._add_api_node(service, path, "API", f"{handler} (Python)")
                except: pass

            # Scan JS Express
            for js_file in src_path.rglob("*.js"):
                if "node_modules" in str(js_file): continue
                try:
                    with open(js_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    for match in gc.PATTERNS['js_express_route'].finditer(content):
                        verb = match.group(1).upper()
                        path = match.group(2)
                        # Handle Express Router prefix if possible (complex), simplistic for now
                        self._add_api_node(service, path, verb, f"{js_file.name} (JS)")
                except: pass

            # Scan Go Http
            for go_file in src_path.rglob("*.go"):
                try:
                    with open(go_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    for match in gc.PATTERNS['go_http_route'].finditer(content):
                        path = match.group(1)
                        self._add_api_node(service, path, "API", f"{go_file.name} (Go)")
                except: pass

    def _add_api_node(self, service, path, method, label_extra):
        # FIX 2: Include service in node_id to prevent cross-service collisions
        node_id = f"{service}:{method} {path}"
        if not any(n['id'] == node_id for n in self.nodes):
            self.nodes.append({
                "id": node_id, "label": path, "service": service,
                "method": method, "path": path, "type": "API", "info": label_extra
            })
            # Store per-service for precise resolution
            self.path_to_api_node[(service, path)] = node_id
            # Also store path-only key as fallback (first-wins, avoids silent overwrites)
            if path not in self.path_to_api_node:
                self.path_to_api_node[path] = node_id

    def _extract_internal_method_nodes(self):
        print("  Scanning Internal Methods...")
        for service in self.services:
            src_path = self.root_path / service / "src"
            if not src_path.exists(): continue
            for java_file in src_path.rglob("*.java"):
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    
                    is_service = gc.PATTERNS['service_annotation'].search(content) or "ServiceImpl" in java_file.name
                    if not is_service: continue
                    
                    class_name = java_file.stem
                    if class_name.endswith("ServiceImpl"):
                        iname = class_name.replace("Impl", "")
                        self.interface_to_impl_map[f"{service}:{iname}"] = f"{service}:{class_name}"
                        
                    for match in gc.PATTERNS['method_def'].finditer(content):
                        m_name = match.group(1)
                        if m_name in ['toString', 'hashCode', 'equals']: continue
                        node_id = f"{service}:{class_name}.{m_name}"
                        
                        self.nodes.append({"id": node_id, "label": f"{class_name}.{m_name}", "service": service, "type": "METHOD"})
                        # For ServiceImpl methods: maps node_id -> itself (identity), so that
                        # _scan_file_for_links emits edges from the method node directly.
                        # (Controller methods map to their API node ID instead — see _extract_api_nodes.)
                        self.method_id_to_node[node_id] = node_id
                except: pass

    def _extract_repository_nodes(self):
        print("  Scanning Repositories...")
        for service in self.services:
            src_path = self.root_path / service / "src"
            if not src_path.exists(): continue
            for java_file in src_path.rglob("*.java"):
                try:
                    with open(java_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                    match = gc.PATTERNS['repository_def'].search(content)
                    if match:
                        repo_name = match.group(1)
                        node_id = f"{service}:{repo_name}"
                        self.nodes.append({"id": node_id, "label": repo_name, "service": service, "type": "REPOSITORY"})
                        self.repository_to_node[repo_name] = node_id
                except: pass

    def _extract_ui_nodes_and_calls(self):
        print("  Scanning UI Calls...")
        ui_path = self.root_path / "ts-ui-dashboard"
        if not ui_path.exists(): return
        
        js_path = ui_path / "static" / "assets" / "js"
        if not js_path.exists(): js_path = ui_path
        
        for js_file in js_path.rglob("*.js"):
            if "node_modules" in str(js_file) or ".min.js" in str(js_file): continue
            try:
                with open(js_file, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
                
                urls = gc.PATTERNS['ui_ajax_url'].findall(content) + gc.PATTERNS['ui_axios_url'].findall(content)
                if urls:
                    ui_node = f"UI {js_file.name}"
                    if not any(n['id'] == ui_node for n in self.nodes):
                        self.nodes.append({"id": ui_node, "label": js_file.name, "service": "ts-ui-dashboard", "type": "UI"})
                    
                    for url in set(urls):
                        target = self._resolve_api_node(url)
                        if target:
                            self.edges.append({"source": ui_node, "target": target, "relation": "CALLS_API", "type": "UI_TO_API"})
            except: pass

    def _link_api_to_internal(self):
        print("  Linking API -> Internal...")
        for service in self.services:
            src_path = self.root_path / service / "src"
            if not src_path.exists(): continue
            for java_file in src_path.rglob("*Controller.java"):
                self._scan_file_for_links(java_file, service)

    def _link_internal_calls(self):
        print("  Linking Internal -> Internal/Repo...")
        for service in self.services:
            src_path = self.root_path / service / "src"
            if not src_path.exists(): continue
            for java_file in src_path.rglob("*ServiceImpl.java"):
                 self._scan_file_for_links(java_file, service)
                 
    def _scan_file_for_links(self, file_path, service):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f: lines = f.readlines()
            
            content_str = "".join(lines)
            field_map = {m.group(2): m.group(1) for m in gc.PATTERNS['field_injection'].finditer(content_str)}
            class_name = file_path.stem
            current_method = None
            
            for line in lines:
                m_match = gc.PATTERNS['method_def'].search(line)
                if m_match:
                    name = m_match.group(1)
                    if name[0].islower() and len(name) > 2 and name not in _SKIP_METHOD_NAMES:
                        current_method = name
                # NOTE: no 'continue' — the same line may also contain method calls to scan
                
                if current_method:
                    raw_source = f"{service}:{class_name}.{current_method}"
                    source_id = self.method_id_to_node.get(raw_source, raw_source)
                    
                    # Check method calls
                    for call in gc.PATTERNS['method_call'].finditer(line):
                        var, method = call.groups()
                        if var in field_map:
                            type_name = field_map[var]
                            
                            # 1. Repo Call
                            if "Repository" in type_name:
                                target = self.repository_to_node.get(type_name, f"{service}:{type_name}")
                                self._add_edge(source_id, target, "CALLS_REPO", "SERVICE_TO_REPOSITORY")
                            
                            # 2. Service Call
                            else:
                                # Resolve Interface -> Impl
                                impl_key = f"{service}:{type_name}Impl"
                                target_class = type_name
                                if f"{service}:{type_name}" in self.interface_to_impl_map:
                                    mapping = self.interface_to_impl_map[f"{service}:{type_name}"]
                                    if mapping.startswith("FEIGN:"):
                                        # It's a Feign client, the node ID uses the Interface name
                                        target_class = type_name
                                    else:
                                        target_class = mapping.split(":")[1]
                                
                                target = f"{service}:{target_class}.{method}"
                                self._add_edge(source_id, target, "CALLS_INTERNAL", "API_TO_INTERNAL" if "Controller" in class_name else "INTERNAL_TO_INTERNAL")

                    # Check Local calls
                    for lc in gc.PATTERNS['local_method_call'].finditer(line):
                        m = lc.group(1)
                        if m not in ['if','for','while','return']:
                            target = f"{service}:{class_name}.{m}"
                            if target != source_id:
                                self._add_edge(source_id, target, "CALLS_LOCAL", "INTERNAL_TO_INTERNAL")
                                
                    # Check External API Calls (RestTemplate)
                    for api_path in gc.PATTERNS['api_path'].findall(line):
                         target_api = self._resolve_api_node(api_path)
                         if target_api:
                             self._add_edge(source_id, target_api, "CALLS_EXTERNAL", "INTERNAL_TO_API")

        except: pass

    def _extract_value_url_fields(self, content):
        """
        Build {field_name: target_service} from @Value annotations with ts- default hostnames.
        Catches cases where services inject the target host via:
            @Value("${ts.order.service.url:ts-order-service}")
            private String tsOrderServiceUrl;
        When the full URL is dynamic (no inline /api/v1/ path), this map lets us
        emit a service-level fallback edge rather than losing the call entirely.
        """
        url_field_map = {}
        for m in gc.PATTERNS['value_default_hostname'].finditer(content):
            target_svc = m.group(1)
            if target_svc not in self.services:
                continue
            # Find the String field name declared within 300 chars after the annotation
            after = content[m.end():m.end() + 300]
            field_m = re.search(r'\bString\s+(\w+)', after)
            if field_m:
                url_field_map[field_m.group(1)] = target_svc
        return url_field_map

    def _analyze_external_calls(self):
        print("  Scanning External API Calls (All Files)...")
        # RestTemplate call pattern: restTemplate.exchange(var, ...) / getForEntity(var,...)
        # Used to catch URL-field-based calls when no /api/v1/ path is inline.
        _RT_CALL = re.compile(
            r'(?:restTemplate|http|template)\s*\.\s*'
            r'(?:exchange|getForEntity|postForEntity|put|delete|postForObject|getForObject)'
            r'\s*\(\s*(\w+)'
        )
        for service in self.services:
            src_path = self.root_path / service / "src"
            if not src_path.exists(): continue
            
            for fpath in src_path.rglob("*.java"):
                # Skip test directories
                if 'test' in fpath.parts:
                    continue
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f: lines = f.readlines()
                    content_str = "".join(lines)
                    class_name = fpath.stem
                    current_method = None

                    # Build @Value URL field map for this file
                    url_field_map = self._extract_value_url_fields(content_str)

                    for line in lines:
                        m_match = gc.PATTERNS['method_def'].search(line)
                        if m_match:
                            name = m_match.group(1)
                            if name[0].islower() and len(name) > 2 and name not in _SKIP_METHOD_NAMES:
                                current_method = name
                        
                        if current_method:
                            source = f"{service}:{class_name}.{current_method}"

                            # Primary: look for inline /api/v1/... path strings
                            for path in gc.PATTERNS['api_path'].findall(line):
                                target = self._resolve_api_node(path, hint_service=service)
                                if target:
                                    self._add_edge(source, target, "CALLS_EXTERNAL", "INTERNAL_TO_API")

                            # Fallback: RestTemplate call on a @Value URL field with no inline path.
                            # Emits a generic cross-service edge to the target service's first endpoint.
                            # This covers fully-dynamic URL construction (host+port fully from @Value).
                            if not gc.PATTERNS['api_path'].search(line):
                                rt_m = _RT_CALL.search(line)
                                if rt_m:
                                    var_name = rt_m.group(1)
                                    target_svc = url_field_map.get(var_name)
                                    if target_svc:
                                        # Use the first registered endpoint of the target service
                                        candidates = [
                                            n for n in self.nodes
                                            if n.get('service') == target_svc and n['type'] == 'API'
                                        ]
                                        if candidates:
                                            self._add_edge(
                                                source, candidates[0]['id'],
                                                "CALLS_VALUE_URL", "INTERNAL_TO_API"
                                            )

                except Exception: pass
        
    def _add_edge(self, source, target, rel, type_):
        # Only add if nodes exist (loose validation)
        # For simplicity, we add edge if ids look valid
        if not any(e['source']==source and e['target']==target for e in self.edges):
            self.edges.append({"source": source, "target": target, "relation": rel, "type": type_})

    def _resolve_api_node(self, url, hint_service=None):
        """Map a URL/path string to an API node id.
        hint_service: if provided, prefer endpoints on that service.
        """
        path = url.split('?')[0] if '?' in url else url
        if "http" in path:
             m = next(gc.PATTERNS['http_url'].finditer(path), None)
             if m: path = m.group(2) if m.group(2) else ""

        # FIX 2 (resolution side): try service-scoped key first
        if hint_service and (hint_service, path) in self.path_to_api_node:
            return self.path_to_api_node[(hint_service, path)]

        if path in self.path_to_api_node:
            return self.path_to_api_node[path]

        # Fuzzy match — skip tuple keys (service, path), only match string keys
        for known, nid in self.path_to_api_node.items():
            if isinstance(known, str) and path.startswith(known) and len(path) > len(known):
                return nid
        return None

    def _synthesize_level2_graph(self):
        print("  Synthesizing Level 2 Graph...")
        # Build adjacency from all raw edges
        adj = defaultdict(list)
        for e in self.edges:
            adj[e['source']].append((e['target'], e['type']))

        api_nodes = [n for n in self.nodes if n['type'] == 'API']
        # FIX 3: Set for O(1) membership checks instead of O(n) list scan
        api_node_ids = {n['id'] for n in api_nodes}
        synthesized_edges = []
        seen_synth = set()  # (source, target) dedup

        # Edge types the BFS follows while walking through internal nodes
        # FIX 1: Added CALLS_FEIGN so Feign proxy chains are traversed;
        #        Added INTERNAL_TO_API so direct RestTemplate calls are followed too.
        TRAVERSE_TYPES = {
            'API_TO_INTERNAL',
            'INTERNAL_TO_INTERNAL',
            'SERVICE_TO_REPOSITORY',
            'CALLS_FEIGN',       # FIX 1: follow Feign proxy hops
            'INTERNAL_TO_API',   # FIX 1: don't stop at first cross-service call
        }

        for start_node in api_nodes:
            start_id = start_node['id']
            queue = [start_id]
            visited = {start_id}

            while queue:
                curr = queue.pop(0)
                for tgt, type_ in adj.get(curr, []):
                    # If we land on another API node — emit a synthesized edge
                    if tgt in api_node_ids and tgt != start_id:
                        key = (start_id, tgt)
                        if key not in seen_synth:
                            seen_synth.add(key)
                            relation = "CALLED_BY_FEIGN" if type_ == "CALLS_FEIGN" else "HTTP_CALL"
                            synthesized_edges.append({
                                "source": start_id,
                                "target": tgt,
                                "relation": relation,
                                "type": "SYNTHESIZED"
                            })
                        # Don't recurse into the target API node — this graph captures
                        # direct API-to-API calls only, not full transitive reachability.
                        # (If A→B→C, you get A→B and B→C edges, but not A→C directly.)
                        continue

                    # Otherwise, keep walking through internal nodes
                    if type_ in TRAVERSE_TYPES and tgt not in visited:
                        visited.add(tgt)
                        queue.append(tgt)

        # Add UI Calls
        user_node = "USER / UI"
        ui_edges = [e for e in self.edges if e['type'] == 'UI_TO_API']
        if ui_edges:
            api_nodes.insert(0, {"id": user_node, "label": "USER / UI", "service": "EXTERNAL", "type": "API"})
            for ue in ui_edges:
                tgt = ue['target']
                key = (user_node, tgt)
                if key not in seen_synth:
                    seen_synth.add(key)
                    synthesized_edges.append({
                        "source": user_node,
                        "target": tgt,
                        "relation": "CALLED_BY_UI",
                        "type": "SYNTHESIZED"
                    })

        output_path = Path("output/level2_api_graph.json")
        with open(output_path, 'w') as f:
            json.dump({"nodes": api_nodes, "links": synthesized_edges}, f, indent=2)

        http_calls = [e for e in synthesized_edges if e['relation'] == 'HTTP_CALL']
        feign_calls = [e for e in synthesized_edges if e['relation'] == 'CALLED_BY_FEIGN']
        ui_calls    = [e for e in synthesized_edges if e['relation'] == 'CALLED_BY_UI']
        print(f"✅ Saved Level 2 Graph: {len(api_nodes)} nodes, {len(synthesized_edges)} edges")
        print(f"   HTTP_CALL: {len(http_calls)}, CALLED_BY_FEIGN: {len(feign_calls)}, CALLED_BY_UI: {len(ui_calls)}")

    def _save_level3_graph(self):
         output_path = Path("output/level3_method_graph.json")
         with open(output_path, 'w') as f:
             json.dump({"nodes": self.nodes, "links": self.edges}, f, indent=2)
         print(f"✅ Saved Level 3 Graph: {len(self.nodes)} Nodes, {len(self.edges)} Edges")

if __name__ == "__main__":
    extractor = InterfaceGraphExtractor()
    extractor.extract()
