"""
prune_method_graph.py
=====================
Post-processing step for Level 3 Method Graph.

Strategy: Node Collapsing (not deletion)
-----------------------------------------
Rather than removing non-core nodes and losing paths, we *collapse* them:

    Before: CoreA → Helper.get() → CoreB
    After:  CoreA → CoreB          (Helper node removed, edge preserved)

This is the same BFS synthesis used in Level 2 to collapse internal chains
into direct API-to-API edges.

Core nodes (always kept):
  - *Controller          — HTTP entry points
  - *ServiceImpl         — business logic, primary fault sites
  - REPOSITORY nodes     — DB boundary
  - *Feign* interfaces   — network boundary (cross-service calls)

Non-core nodes (collapsed):
  - Service *interfaces* (no "Impl" suffix) — pure delegation, no logic
  - *Config, *Application — Spring config/wiring, not business logic
  - *Util, *Utils         — static helpers
  - *Type, *Status, *Enum — enum/constant classes
  - *Data, *Info, *Result, *DTO, *Request, *Response — data containers
  - *Properties           — configuration holder

Output: output/level3_method_graph_pruned.json
"""

import json
import re
from collections import defaultdict
from pathlib import Path


# ---------------------------------------------------------------------------
# Core / non-core classification
# ---------------------------------------------------------------------------

# Suffixes of class names whose methods are always KEPT
_CORE_SUFFIXES = {
    'Impl',         # ServiceImpl — main fault sites
    'Controller',   # HTTP entry points
    'Controlller',  # typo variant present in Train Ticket
    'Repository',   # DB interface methods
}


# Suffixes whose methods are collapsed (connective tissue)
_COLLAPSE_SUFFIXES = {
    'Config', 'Configuration',
    'Service',          # interface-only (no Impl) — pure delegation
    'Util', 'Utils',
    'Helper',
    'Type', 'Status', 'Gender',
    'Enum', 'Constant',
    'Data', 'Info', 'Result',
    'DTO', 'Request', 'Response',
    'Properties',
    'Application',      # Spring boot main — not fault-localizable
    'Handler',
    'Exception',
    'Generator',
    'Provider',
}


def _class_of(node_id: str) -> str:
    """Extract ClassName from 'service:ClassName.methodName'."""
    part = node_id.split(':', 1)[1] if ':' in node_id else node_id
    return part.split('.')[0]


def _suffix_of(class_name: str) -> str:
    """Return the last CamelCase segment of a class name."""
    parts = re.findall('[A-Z][a-z0-9]*', class_name)
    return parts[-1] if parts else class_name


def is_core(node: dict) -> bool:
    """Return True if this node should be kept in the pruned graph."""
    # REPOSITORY nodes are always core
    if node.get('type') == 'REPOSITORY':
        return True

    node_id = node['id']
    class_name = _class_of(node_id)

    # Feign clients kept (cross-service network boundary)
    if 'Feign' in class_name or 'feign' in class_name:
        return True

    suffix = _suffix_of(class_name)

    if suffix in _CORE_SUFFIXES:
        return True

    if suffix in _COLLAPSE_SUFFIXES:
        return False

    # Default: keep (unknown suffixes treated as potentially important)
    return True


# ---------------------------------------------------------------------------
# Edge shortcutting (BFS collapse)
# ---------------------------------------------------------------------------

def collapse_non_core(nodes: list, edges: list) -> tuple[list, list]:
    """
    For every non-core node N:
      - Find all predecessors P that have an edge P → N
      - Find all successors S that N has an edge N → S
      - Add a shortcut edge P → S for every (P, S) combination
      - Remove N and all its incident edges

    Iterates until no non-core nodes remain (handles chains like
    CoreA → Helper1 → Helper2 → CoreB correctly).
    """
    # Mark nodes
    for n in nodes:
        n['core'] = is_core(n)

    node_map = {n['id']: n for n in nodes}

    # Iteratively collapse — loop handles chains of non-core nodes
    max_iterations = 20
    for iteration in range(max_iterations):
        non_core_ids = {n['id'] for n in nodes if not n.get('core', True)}
        if not non_core_ids:
            break

        # Build adjacency for this iteration
        out_adj  = defaultdict(set)   # source → {targets}
        in_adj   = defaultdict(set)   # target → {sources}
        out_rel  = {}                 # (src, tgt) → relation   [outgoing]
        in_rel   = {}                 # (src, tgt) → relation   [incoming, fallback]

        for e in edges:
            src, tgt = e['source'], e['target']
            out_adj[src].add(tgt)
            in_adj[tgt].add(src)
            out_rel[(src, tgt)] = e['relation']
            in_rel[(src, tgt)]  = e['relation']

        new_edges_set = set()   # (src, tgt, relation)
        collapsed_this_round = set()

        for nc in non_core_ids:
            preds = in_adj.get(nc, set())
            succs = out_adj.get(nc, set())

            # For each predecessor → successor pair, create a shortcut.
            # FIX 3: Use the OUTGOING relation (NC→S) for the shortcut label.
            # This preserves CALLS_REPO when collapsing through a helper that
            # sits between a ServiceImpl method and a Repository call.
            # Fall back to incoming (P→NC) if no outgoing relation exists.
            for p in preds:
                for s in succs:
                    if p == s:
                        continue
                    rel = out_rel.get((nc, s)) or in_rel.get((p, nc), 'CALLS')
                    new_edges_set.add((p, s, rel))

            collapsed_this_round.add(nc)

        if not collapsed_this_round:
            break

        # Remove collapsed nodes and all their incident edges
        nodes  = [n for n in nodes if n['id'] not in collapsed_this_round]
        edges  = [e for e in edges
                  if e['source'] not in collapsed_this_round
                  and e['target'] not in collapsed_this_round]

        # Add shortcut edges (deduplicated)
        existing = {(e['source'], e['target'], e['relation']) for e in edges}
        for src, tgt, rel in new_edges_set:
            if (src, tgt, rel) not in existing:
                existing.add((src, tgt, rel))
                edges.append({'source': src, 'target': tgt,
                               'relation': rel, 'type': 'COLLAPSED'})

    else:
        # Iteration cap hit — some non-core chains may not be fully resolved
        remaining_nc = {n['id'] for n in nodes if not n.get('core', True)}
        if remaining_nc:
            print(f"⚠️  Warning: iteration cap ({max_iterations}) reached. "
                  f"{len(remaining_nc)} non-core nodes not fully collapsed.")

    return nodes, edges


# ---------------------------------------------------------------------------
# Self-loop and dead-node cleanup
# ---------------------------------------------------------------------------

def cleanup(nodes: list, edges: list) -> tuple[list, list]:
    """Remove self-loops and edges referencing removed nodes."""
    live_ids = {n['id'] for n in nodes}
    edges = [
        e for e in edges
        if e['source'] != e['target']           # no self-loops
        and e['source'] in live_ids             # both endpoints exist
        and e['target'] in live_ids
    ]
    return nodes, edges


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    input_path  = Path('output/level3_method_graph.json')
    output_path = Path('output/level3_method_graph_pruned.json')

    with open(input_path) as f:
        g = json.load(f)

    nodes_in = g['nodes']
    edges_in = g['links']

    print(f"Input:  {len(nodes_in)} nodes, {len(edges_in)} edges")

    # --- Classify ---
    core_count    = sum(1 for n in nodes_in if is_core(n))
    noncor_count  = len(nodes_in) - core_count
    print(f"  Core nodes     : {core_count}")
    print(f"  Non-core nodes : {noncor_count} (will be collapsed)")

    # --- Collapse ---
    nodes_out, edges_out = collapse_non_core(nodes_in, edges_in)
    nodes_out, edges_out = cleanup(nodes_out, edges_out)

    # --- Stats ---
    from collections import Counter
    rel_counts = Counter(e['relation'] for e in edges_out)
    svc_counts = Counter(n['service'] for n in nodes_out if n.get('type') == 'METHOD')

    print(f"\nOutput: {len(nodes_out)} nodes, {len(edges_out)} edges")
    print(f"  Nodes removed  : {len(nodes_in) - len(nodes_out)}")
    print(f"  Edges (net)    : {len(edges_in)} → {len(edges_out)}")
    print("\nEdge breakdown:")
    for r, c in sorted(rel_counts.items(), key=lambda x: -x[1]):
        print(f"  {r}: {c}")
    print("\nMethod nodes by service:")
    for svc, cnt in sorted(svc_counts.items(), key=lambda x: -x[1]):
        print(f"  {cnt:4d}  {svc}")

    # --- Save ---
    output_path.parent.mkdir(exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump({"nodes": nodes_out, "links": edges_out}, f, indent=2)
    print(f"\n✅ Saved pruned graph → {output_path}")


if __name__ == '__main__':
    main()
