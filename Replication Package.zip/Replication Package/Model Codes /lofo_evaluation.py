#!/usr/bin/env python3
"""
lofo_evaluation.py
==================
Leave-One-Fault-Out (LOFO) cross-validation for GAT fault localization.

For each of the N faulty nodes f_i:
  - Train on labels from all faulty nodes EXCEPT f_i
  - f_i is still a visible node in the graph (participates in message passing)
    but is NOT labelled as faulty during training (excluded from train_mask)
  - After training, evaluate: for each failing test whose fault IS f_i,
    does the model rank f_i in the top-1/3/5 of the covered methods?

This measures whether the model learns transferable structural fault patterns
(high betweenness, high complexity, …) rather than memorising node identities.

Configs tested:
  a) best ablation config  : 15_size_coupling_group (loc + fan_out + fan_in + param_count)
  b) all_metrics           : all 6 metrics  
  c) no_metrics            : base 8-dim only (lower bound)

N_SEEDS seeds per fold to account for random init variance.

Run with:
  /User_Path/Codes/.venv/bin/python3 lofo_evaluation.py
"""

import json
import math
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GATConv

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

ROOT = Path(
    "/User_Path/"
    "Dataset/train-ticket-with-test-suites-1.0.0"
)
sys.path.insert(0, str(ROOT))

# ── paths ─────────────────────────────────────────────────────────────────────
_GRAPH_PRUNED = ROOT / "output" / "level3_method_graph_pruned.json"
GRAPH_PATH    = _GRAPH_PRUNED if _GRAPH_PRUNED.exists() else ROOT / "level3_method_graph.json"
TESTS_PATH    = ROOT / "test_method_paths.json"
METRICS_PATH  = ROOT / "output" / "code_metrics_full.json"
OUTPUT_DIR    = ROOT / "output"
PLOTS_DIR     = OUTPUT_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

# ── reusable helpers from ablation_study ──────────────────────────────────────
from ablation_study import (
    EDGE_TYPE_MAP,
    NOISE_PATTERNS,
    CONFIGS,
    build_edges_l3_local,
    normalise_metrics,
    is_noise_method,
    FaultLocGAT_flexible,
)
from run_gnn_optionB import compute_ochiai, top_k_accuracy

# ── hyperparameters ───────────────────────────────────────────────────────────
N_SEEDS = 5
EPOCHS  = 300
LR      = 0.005

# Configs to evaluate under LOFO
LOFO_CONFIGS = {
    "15_size_coupling_group": CONFIGS["15_size_coupling_group"],   # best from ablation
    "01_all_metrics":         CONFIGS["01_all_metrics"],
    "00_no_metrics":          CONFIGS["00_no_metrics"],
}


# ─────────────────────────────────────────────────────────────────────────────
# Data builder — identical to ablation_study but with held_out_fault param
# ─────────────────────────────────────────────────────────────────────────────
def build_pyg_data_lofo(
    tests:           list,
    cover_field:     str,
    faulty_field:    str,
    infra_ids:       set,
    infra_type:      str,
    edges_raw:       list,
    code_metrics:    dict,
    config:          dict,
    held_out_fault:  str,          # this fault is EXCLUDED from train_mask
) -> tuple:
    """
    Same as build_pyg_data_configurable except:
      - held_out_fault.y  = 1.0 (we record its true label)
      - held_out_fault is REMOVED from train_set so the model never sees its label
    """
    node_metric_names = config["node_metrics"]
    edge_metric_names = config["edge_metrics"]
    in_features = 8 + len(node_metric_names)
    edge_dim    = 1 + len(edge_metric_names)

    all_metric_names = list(set(node_metric_names) | set(edge_metric_names))
    norm_metrics = normalise_metrics(code_metrics, all_metric_names) if all_metric_names else {}

    ochiai, ef, ep = compute_ochiai(tests, cover_field)
    nf_total = max(sum(1 for t in tests if t["status"] == "FAILING"), 1)
    np_total = max(sum(1 for t in tests if t["status"] == "PASSING"), 1)

    all_faulty   = {t[faulty_field] for t in tests if t.get(faulty_field)}
    train_faulty = all_faulty - {held_out_fault}   # hide one fault from training

    test_ids     = {t["test_id"] for t in tests}
    failing_ids  = {t["test_id"] for t in tests if t["status"] == "FAILING"}

    all_ids = list(test_ids | infra_ids)
    idx_map = {nid: i for i, nid in enumerate(all_ids)}

    in_deg  = defaultdict(int)
    out_deg = defaultdict(int)
    for src, tgt, _ in edges_raw:
        in_deg[tgt]  += 1
        out_deg[src] += 1
    max_in  = max(in_deg.values(),  default=1)
    max_out = max(out_deg.values(), default=1)

    feats, labels = [], []
    for nid in all_ids:
        is_fail = 1.0 if nid in failing_ids else 0.0
        is_pass = 1.0 if (nid in test_ids and nid not in failing_ids) else 0.0
        is_inf  = 1.0 if nid in infra_ids else 0.0
        oc      = ochiai.get(nid, 0.0)
        n_ef    = ef.get(nid, 0) / nf_total
        n_ep    = ep.get(nid, 0) / np_total
        indeg   = in_deg.get(nid,  0) / max_in
        outdeg  = out_deg.get(nid, 0) / max_out
        base    = [is_fail, is_pass, is_inf, oc, n_ef, n_ep, indeg, outdeg]

        if node_metric_names and nid in infra_ids and infra_type == "METHOD":
            nm = norm_metrics.get(nid, {})
            metric_feat = [nm.get(m, 0.0) for m in node_metric_names]
        else:
            metric_feat = [0.0] * len(node_metric_names)

        feats.append(base + metric_feat)
        # Label = 1 for truly faulty infra nodes (including held-out)
        labels.append(1.0 if (nid in all_faulty and nid in infra_ids) else 0.0)

    x = torch.tensor(feats,  dtype=torch.float)
    y = torch.tensor(labels, dtype=torch.float)

    edge_list, edge_attrs = [], []
    zero_m = {m: 0.0 for m in edge_metric_names}
    for src, tgt, etype in edges_raw:
        if src not in idx_map or tgt not in idx_map:
            continue
        w     = EDGE_TYPE_MAP.get(etype, 0.5)
        src_m = norm_metrics.get(src, zero_m)
        tgt_m = norm_metrics.get(tgt, zero_m)
        diffs = [src_m.get(m, 0.0) - tgt_m.get(m, 0.0) for m in edge_metric_names]
        edge_list.append([idx_map[src], idx_map[tgt]])
        edge_attrs.append([w] + diffs)

    if edge_list:
        edge_index = torch.tensor(edge_list, dtype=torch.long).t().contiguous()
        edge_attr  = torch.tensor(edge_attrs, dtype=torch.float)
    else:
        edge_index = torch.zeros((2, 0), dtype=torch.long)
        edge_attr  = torch.zeros((0, edge_dim), dtype=torch.float)

    # Train mask: covered nodes from ALL tests + known faulty nodes − held_out
    covered_set = {nid for t in tests for nid in t.get(cover_field, [])}
    train_set   = (covered_set | train_faulty) & infra_ids
    # Explicitly exclude the held-out fault even if it was covered by passing tests
    train_set.discard(held_out_fault)
    train_mask = torch.tensor([nid in train_set for nid in all_ids])

    data = Data(x=x, y=y, edge_index=edge_index, edge_attr=edge_attr,
                train_mask=train_mask)
    return data, idx_map, all_ids, in_features, edge_dim


# ─────────────────────────────────────────────────────────────────────────────
# Training
# ─────────────────────────────────────────────────────────────────────────────
def run_one_seed(data, all_ids, method_ids, in_features, edge_dim):
    model = FaultLocGAT_flexible(in_features=in_features, edge_dim=edge_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=1e-4)

    n_pos = max(data.y[data.train_mask].sum().item(), 1)
    n_neg = data.train_mask.sum().item() - n_pos
    pos_weight = torch.tensor([max(n_neg / n_pos, 1.0)])
    criterion  = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    model.train()
    for _ in range(EPOCHS):
        optimizer.zero_grad()
        out  = model(data)
        loss = criterion(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

    model.eval()
    with torch.no_grad():
        probs = torch.sigmoid(model(data)).numpy()
    return {nid: float(probs[i]) for i, nid in enumerate(all_ids) if nid in method_ids}


# ─────────────────────────────────────────────────────────────────────────────
# LOFO evaluation for one fault
# ─────────────────────────────────────────────────────────────────────────────
def evaluate_lofo_fault(held_out_fault, tests, method_ids, edges_raw,
                        raw_code_metrics, config):
    """
    Returns (top1_scores, top3_scores, top5_scores) across N_SEEDS seeds
    for the failing tests whose fault == held_out_fault.
    """
    # Only evaluate on tests linked to this specific fault
    fault_tests = [t for t in tests
                   if t.get("faulty_method") == held_out_fault
                   and t["status"] == "FAILING"]
    if not fault_tests:
        return [], [], []

    top1_seeds, top3_seeds, top5_seeds = [], [], []

    for seed in range(N_SEEDS):
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)

        data, idx_map, all_ids, inf, edim = build_pyg_data_lofo(
            tests, "method_path", "faulty_method",
            method_ids, "METHOD", edges_raw,
            raw_code_metrics, config,
            held_out_fault=held_out_fault,
        )
        scores = run_one_seed(data, all_ids, method_ids, inf, edim)

        # Evaluate on ONLY the tests for this fault
        acc, _, _ = top_k_accuracy(
            fault_tests, "method_path", "faulty_method", scores
        )
        top1_seeds.append(acc[1])
        top3_seeds.append(acc[3])
        top5_seeds.append(acc[5])

    return top1_seeds, top3_seeds, top5_seeds


# ─────────────────────────────────────────────────────────────────────────────
# Plotting
# ─────────────────────────────────────────────────────────────────────────────
def plot_lofo_per_fault(lofo_results: dict, config_name: str):
    """Bar chart: Top-1 mean per fault for one config."""
    faults   = list(lofo_results.keys())
    means    = [np.mean(lofo_results[f]["top1"]) for f in faults]
    stds     = [np.std(lofo_results[f]["top1"])  for f in faults]
    n_tests  = [lofo_results[f]["n_tests"]        for f in faults]

    fig, ax = plt.subplots(figsize=(14, 6), dpi=150)
    colors = ["#27AE60" if m >= 0.8 else "#E67E22" if m >= 0.5 else "#E74C3C"
              for m in means]
    y_pos = range(len(faults))
    ax.barh(list(y_pos), means, xerr=stds, color=colors,
            edgecolor="white", height=0.65, capsize=4)
    ax.axvline(np.mean(means), color="navy", linestyle="--", linewidth=1.5,
               label=f"Mean = {np.mean(means):.1%}")
    ax.set_yticks(list(y_pos))
    short_labels = [f.split(":")[-1] + f" (n={n})" for f, n in zip(faults, n_tests)]
    ax.set_yticklabels(short_labels, fontsize=8)
    ax.set_xlabel("Top-1 Accuracy (held-out fault)", fontsize=11)
    ax.set_title(f"LOFO Per-Fault Top-1 Accuracy — {config_name}\n"
                 f"({N_SEEDS} seeds, mean ± std | green≥80% orange≥50% red<50%)",
                 fontsize=11, fontweight="bold")
    ax.set_xlim(0, 1.15)
    ax.legend(fontsize=10)
    ax.grid(axis="x", alpha=0.3)
    for i, (m, s) in enumerate(zip(means, stds)):
        ax.text(m + s + 0.02, i, f"{m:.1%}", va="center", fontsize=8)
    plt.tight_layout()
    path = PLOTS_DIR / f"lofo_per_fault_{config_name}.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_lofo_config_comparison(all_results: dict):
    """Side-by-side Top-1/3/5 comparison across configs."""
    cfg_names = list(all_results.keys())
    x = np.arange(3)
    width = 0.25
    colors = ["#2980B9", "#E67E22", "#7F8C8D"]

    fig, ax = plt.subplots(figsize=(9, 6), dpi=150)
    for i, (cname, color) in enumerate(zip(cfg_names, colors)):
        r = all_results[cname]["aggregate"]
        vals = [r["top1_mean"], r["top3_mean"], r["top5_mean"]]
        errs = [r["top1_std"],  0,              0]
        bars = ax.bar(x + i * width, vals, width, label=cname,
                      color=color, alpha=0.85,
                      yerr=errs, capsize=5, error_kw={"linewidth": 1.5})
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, v + 0.01,
                    f"{v:.1%}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x + width)
    ax.set_xticklabels(["Top-1", "Top-3", "Top-5"], fontsize=12)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Accuracy (mean across all folds)", fontsize=11)
    ax.set_title("LOFO Cross-Validation: Top-k Accuracy by Configuration\n"
                 f"({len(list(all_results.values())[0]['per_fault'])} folds × {N_SEEDS} seeds per fold)",
                 fontsize=11, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    path = PLOTS_DIR / "lofo_config_comparison.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_lofo_vs_insample(all_lofo: dict, insample_path: Path):
    """Compare LOFO vs in-sample accuracy for each config."""
    try:
        with open(insample_path) as f:
            ablation = json.load(f)
    except FileNotFoundError:
        print("  (skipping LOFO vs in-sample plot — ablation_results.json not found)")
        return

    cfg_names = list(all_lofo.keys())
    lofo_vals   = [all_lofo[c]["aggregate"]["top1_mean"] for c in cfg_names]
    sample_vals = [ablation.get(c, {}).get("top1_mean", 0.0)  for c in cfg_names]

    fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
    x = np.arange(len(cfg_names))
    w = 0.35
    ax.bar(x - w/2, sample_vals, w, label="In-sample (transductive)", color="#2980B9", alpha=0.85)
    ax.bar(x + w/2, lofo_vals,   w, label="LOFO (held-out fault)",    color="#E74C3C", alpha=0.85)
    for xi, (s, l) in enumerate(zip(sample_vals, lofo_vals)):
        ax.text(xi - w/2, s + 0.01, f"{s:.1%}", ha="center", fontsize=8)
        ax.text(xi + w/2, l + 0.01, f"{l:.1%}", ha="center", fontsize=8)
        ax.annotate("", xy=(xi + w/2, l), xytext=(xi - w/2, s),
                    arrowprops=dict(arrowstyle="->", color="gray", lw=1.2))

    ax.set_xticks(x)
    ax.set_xticklabels(cfg_names, rotation=12, fontsize=8)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Top-1 Accuracy", fontsize=11)
    ax.set_title("In-Sample vs LOFO Top-1 Accuracy\n"
                 "(gap = amount attributable to label memorisation)",
                 fontsize=11, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    path = PLOTS_DIR / "lofo_vs_insample.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 70)
    print("LOFO EVALUATION — Leave-One-Fault-Out Cross-Validation")
    print(f"Seeds per fold: {N_SEEDS}  |  Epochs: {EPOCHS}")
    print(f"Configs: {list(LOFO_CONFIGS.keys())}")
    print("=" * 70)

    # ── load ──────────────────────────────────────────────────────────────────
    with open(GRAPH_PATH)   as f: g3           = json.load(f)
    with open(TESTS_PATH)   as f: tests        = json.load(f)
    with open(METRICS_PATH) as f: raw_metrics  = json.load(f)

    method_ids_raw = {n["id"] for n in g3["nodes"] if n.get("type") == "METHOD"}
    method_ids     = {m for m in method_ids_raw if not is_noise_method(m)}
    edges_raw      = build_edges_l3_local(tests, method_ids, g3)

    all_faulty = sorted({t["faulty_method"] for t in tests
                         if t.get("faulty_method") and t["faulty_method"] in method_ids})
    print(f"\nMETHOD nodes : {len(method_ids)}")
    print(f"L3 edges     : {len(edges_raw)}")
    print(f"Faulty nodes : {len(all_faulty)}")
    print()
    for fi, f in enumerate(all_faulty, 1):
        n = sum(1 for t in tests if t.get("faulty_method") == f and t["status"] == "FAILING")
        print(f"  [{fi:02d}] {f}  ({n} failing tests)")

    # ── estimate time ─────────────────────────────────────────────────────────
    print("\nEstimating runtime...")
    t0 = time.time()
    torch.manual_seed(0); np.random.seed(0); random.seed(0)
    cfg0 = LOFO_CONFIGS["00_no_metrics"]
    _d, _, _ids, _inf, _edim = build_pyg_data_lofo(
        tests, "method_path", "faulty_method",
        method_ids, "METHOD", edges_raw, raw_metrics, cfg0,
        held_out_fault=all_faulty[0],
    )
    run_one_seed(_d, _ids, method_ids, _inf, _edim)
    t_one = time.time() - t0
    total_est = t_one * len(all_faulty) * N_SEEDS * len(LOFO_CONFIGS) / 60
    print(f"One seed/fold: {t_one:.1f}s  →  estimated total: ~{total_est:.0f} min")

    # ── LOFO loop ─────────────────────────────────────────────────────────────
    all_lofo_results: dict = {}   # config_name → {per_fault, aggregate}

    for cfg_name, config in LOFO_CONFIGS.items():
        print(f"\n{'='*60}")
        print(f"Config: {cfg_name}  —  {config['description']}")
        print(f"{'='*60}")

        per_fault: dict = {}
        t_cfg_start = time.time()

        for fi, fault in enumerate(all_faulty, 1):
            n_fault_tests = sum(1 for t in tests
                                if t.get("faulty_method") == fault
                                and t["status"] == "FAILING")
            print(f"  [{fi:02d}/{len(all_faulty)}] {fault.split(':')[-1]}  "
                  f"({n_fault_tests} failing tests)", end=" ... ")
            t_fault = time.time()

            top1, top3, top5 = evaluate_lofo_fault(
                fault, tests, method_ids, edges_raw, raw_metrics, config
            )

            elapsed_f = time.time() - t_fault
            print(f"Top-1={np.mean(top1):.1%} ± {np.std(top1):.1%}  "
                  f"Top-3={np.mean(top3):.1%}  ({elapsed_f:.0f}s)")

            per_fault[fault] = {
                "top1": top1, "top3": top3, "top5": top5,
                "n_tests": n_fault_tests,
                "top1_mean": float(np.mean(top1)),
                "top1_std":  float(np.std(top1)),
                "top3_mean": float(np.mean(top3)),
                "top5_mean": float(np.mean(top5)),
            }

        # Aggregate across faults (weighted by n_tests)
        all_top1 = [s for f in per_fault for s in per_fault[f]["top1"]]
        all_top3 = [s for f in per_fault for s in per_fault[f]["top3"]]
        all_top5 = [s for f in per_fault for s in per_fault[f]["top5"]]

        # Per-fault means (one mean per fault, then average of those)
        fault_means_1 = [per_fault[f]["top1_mean"] for f in per_fault]
        fault_means_3 = [per_fault[f]["top3_mean"] for f in per_fault]
        fault_means_5 = [per_fault[f]["top5_mean"] for f in per_fault]

        aggregate = {
            "top1_mean": float(np.mean(fault_means_1)),
            "top1_std":  float(np.std(fault_means_1)),
            "top3_mean": float(np.mean(fault_means_3)),
            "top5_mean": float(np.mean(fault_means_5)),
            "n_folds":   len(per_fault),
        }

        elapsed_cfg = time.time() - t_cfg_start
        print(f"\n  ── {cfg_name} aggregate ──")
        print(f"  Top-1: {aggregate['top1_mean']:.1%} ± {aggregate['top1_std']:.1%}")
        print(f"  Top-3: {aggregate['top3_mean']:.1%}")
        print(f"  Top-5: {aggregate['top5_mean']:.1%}")
        print(f"  ({elapsed_cfg:.0f}s total for this config)")

        all_lofo_results[cfg_name] = {
            "description": config["description"],
            "per_fault":   per_fault,
            "aggregate":   aggregate,
        }

        # Incremental save
        with open(OUTPUT_DIR / "lofo_results_partial.json", "w") as f:
            json.dump(all_lofo_results, f, indent=2)

    # ── Print summary table ────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("=== LOFO CROSS-VALIDATION SUMMARY ===")
    print("=" * 70)
    print(f"{'Config':<28} {'Top-1 mean±std':>18}  {'Top-3':>7}  {'Top-5':>7}  {'Folds':>6}")
    print("-" * 70)
    for cname, r in all_lofo_results.items():
        a = r["aggregate"]
        print(f"{cname:<28} {a['top1_mean']:>7.1%} ± {a['top1_std']:>5.1%}  "
              f"{a['top3_mean']:>7.1%}  {a['top5_mean']:>7.1%}  {a['n_folds']:>6}")

    # Per-fault detail for best config
    best_cfg = max(all_lofo_results, key=lambda c: all_lofo_results[c]["aggregate"]["top1_mean"])
    print(f"\n--- Per-Fault Detail: {best_cfg} ---")
    print(f"{'Fault (short)':<45} {'Top-1':>7}  {'Top-3':>7}  {'Top-5':>7}  {'n_tests':>8}")
    print("-" * 78)
    for fault, r in all_lofo_results[best_cfg]["per_fault"].items():
        short = fault.split(":")[-1][:44]
        print(f"{short:<45} {r['top1_mean']:>7.1%}  {r['top3_mean']:>7.1%}  "
              f"{r['top5_mean']:>7.1%}  {r['n_tests']:>8}")

    # Gap analysis vs in-sample
    print("\n--- In-Sample vs LOFO Gap (measures label memorisation) ---")
    ablation_path = OUTPUT_DIR / "ablation_results.json"
    if ablation_path.exists():
        with open(ablation_path) as f:
            ablation = json.load(f)
        for cname in all_lofo_results:
            lofo_top1   = all_lofo_results[cname]["aggregate"]["top1_mean"]
            sample_top1 = ablation.get(cname, {}).get("top1_mean", None)
            if sample_top1 is not None:
                gap = sample_top1 - lofo_top1
                print(f"  {cname:<28}  in-sample={sample_top1:.1%}  "
                      f"LOFO={lofo_top1:.1%}  gap={gap:+.1%}")

    # ── Save final results ────────────────────────────────────────────────────
    out_path = OUTPUT_DIR / "lofo_results.json"
    with open(out_path, "w") as f:
        json.dump(all_lofo_results, f, indent=2)
    print(f"\nSaved → {out_path}")

    # ── Plots ─────────────────────────────────────────────────────────────────
    print("\nGenerating plots...")
    for cname, r in all_lofo_results.items():
        try:
            plot_lofo_per_fault(r["per_fault"], cname)
        except Exception as e:
            print(f"  Plot per-fault {cname} failed: {e}")
    try:
        plot_lofo_config_comparison(all_lofo_results)
    except Exception as e:
        print(f"  Config comparison plot failed: {e}")
    try:
        plot_lofo_vs_insample(all_lofo_results, ablation_path)
    except Exception as e:
        print(f"  LOFO vs in-sample plot failed: {e}")

    # ── Final message ──────────────────────────────────────────────────────────
    best_r = all_lofo_results[best_cfg]["aggregate"]
    print(f"\nLOFO complete: {len(all_faulty)} folds × {N_SEEDS} seeds × "
          f"{len(LOFO_CONFIGS)} configs. "
          f"Best: {best_cfg} Top-1={best_r['top1_mean']:.1%}. "
          f"Results → {out_path}")


if __name__ == "__main__":
    main()
