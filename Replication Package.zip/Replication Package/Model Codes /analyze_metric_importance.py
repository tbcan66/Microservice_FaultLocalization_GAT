#!/usr/bin/env python3
"""
analyze_metric_importance.py
============================
Definition A analysis: does the metric value differ significantly between
faulty and non-faulty method nodes, independent of the GNN.

15 metrics across 5 dimensions:
  Complexity  : cyclomatic_complexity, cognitive_complexity, max_nesting_depth,
                return_point_count
  Size        : loc, statement_count, param_count
  Coupling    : fan_out, fan_in, exception_count, external_service_calls
  Cohesion    : variable_spread, comment_density
  Graph       : pagerank, betweenness_centrality
"""

import json
import re
import random
import numpy as np

class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy scalar types."""
    def default(self, obj):
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)
import collections
from pathlib import Path
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import networkx as nx

# ─── Reproducibility ─────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ─── Paths ────────────────────────────────────────────────────────────────────
ROOT = Path(
    "/User_Path/"
    "Dataset/train-ticket-with-test-suites-1.0.0"
)

# Accept either the pruned or the full graph
GRAPH_PRUNED = ROOT / "output" / "level3_method_graph_pruned.json"
GRAPH_FULL   = ROOT / "level3_method_graph.json"
GRAPH        = GRAPH_PRUNED if GRAPH_PRUNED.exists() else GRAPH_FULL

TEST_PATHS   = ROOT / "test_method_paths.json"
OUTPUT_DIR   = ROOT / "output"
PLOTS_DIR    = OUTPUT_DIR / "plots"
METRICS_OUT  = OUTPUT_DIR / "code_metrics_full.json"
STATS_OUT    = OUTPUT_DIR / "metric_importance_stats.json"
INTERP_OUT   = OUTPUT_DIR / "metric_importance_interpretation.txt"

OUTPUT_DIR.mkdir(exist_ok=True)
PLOTS_DIR.mkdir(exist_ok=True)

# ─── Metric metadata ──────────────────────────────────────────────────────────
ALL_METRICS = [
    "cyclomatic_complexity",
    "cognitive_complexity",
    "max_nesting_depth",
    "return_point_count",
    "loc",
    "statement_count",
    "param_count",
    "fan_out",
    "fan_in",
    "exception_count",
    "external_service_calls",
    "variable_spread",
    "comment_density",
    "pagerank",
    "betweenness_centrality",
]

DIMENSION_MAP = {
    "cyclomatic_complexity":   "Complexity",
    "cognitive_complexity":    "Complexity",
    "max_nesting_depth":       "Complexity",
    "return_point_count":      "Complexity",
    "loc":                     "Size",
    "statement_count":         "Size",
    "param_count":             "Size",
    "fan_out":                 "Coupling",
    "fan_in":                  "Coupling",
    "exception_count":         "Coupling",
    "external_service_calls":  "Coupling",
    "variable_spread":         "Cohesion",
    "comment_density":         "Cohesion",
    "pagerank":                "Graph Structure",
    "betweenness_centrality":  "Graph Structure",
}

DIM_COLORS = {
    "Complexity":      "#E67E22",
    "Size":            "#27AE60",
    "Coupling":        "#8E44AD",
    "Cohesion":        "#16A085",
    "Graph Structure": "#2C3E50",
}

FAULTY_COLOR     = "#E74C3C"
NON_FAULTY_COLOR = "#3498DB"

# ─── Fan-out exclusion set ────────────────────────────────────────────────────
FANOUT_EXCLUDE = {
    "this", "log", "logger", "system", "string", "math",
    "arrays", "collections", "optional", "assert",
}

# ─── Regex patterns ───────────────────────────────────────────────────────────
CC_PATTERN = re.compile(
    r'\b(if|else\s+if|for|while|do|case|catch|switch)\b'
    r'|(&&|\|\||\?(?!:))'
)
FANOUT_PATTERN    = re.compile(r'\b([a-z][a-zA-Z0-9_]*)\.([a-zA-Z0-9_]+)\s*\(')
METHOD_SIG_PAT    = re.compile(
    r'(?:(?:public|private|protected|static|final|synchronized|abstract|'
    r'native|default|override)\s+)*'
    r'(?:[\w<>\[\],\s]+?\s+)?'
    r'(\w+)\s*\('
    r'([^)]*)\)'
    r'\s*(?:throws\s+[\w\s,]+)?\s*\{'
)
CATCH_PAT         = re.compile(r'\bcatch\s*\(\s*([\w|]+)')
EXT_SVC_PAT       = re.compile(
    r'(restTemplate|feignClient|\.exchange|\.getForEntity|\.postForEntity|'
    r'\.postForObject|\.getForObject)\b'
)
RETURN_PAT        = re.compile(r'\breturn\b')


# ─────────────────────────────────────────────────────────────────────────────
# Source file locator
# ─────────────────────────────────────────────────────────────────────────────
def find_java_file(service: str, class_name: str) -> Path | None:
    base = ROOT / service / "src" / "main"
    if not base.exists():
        return None
    for p in base.rglob(f"{class_name}.java"):
        parts = p.relative_to(ROOT).parts[2:]
        if not any(
            part.lower() in ("test", "tests") or part.lower().startswith("test")
            for part in parts
        ):
            return p
    # broader fallback
    base2 = ROOT / service / "src"
    if not base2.exists():
        return None
    for p in base2.rglob(f"{class_name}.java"):
        parts = p.relative_to(ROOT).parts[2:]
        if not any(
            part.lower() in ("test", "tests") or part.lower().startswith("test")
            for part in parts
        ):
            return p
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Method body extraction (brace-depth counting)
# ─────────────────────────────────────────────────────────────────────────────
def strip_string_literals(line: str) -> str:
    line = re.sub(r'"(?:[^"\\]|\\.)*"', '""', line)
    line = re.sub(r"'(?:[^'\\]|\\.)*'", "''", line)
    return line

def strip_inline_comment(line: str) -> str:
    return re.sub(r'//.*$', '', line)

def extract_method_body(source: str, method_name: str) -> str | None:
    lines = source.splitlines()
    n = len(lines)
    for i, line in enumerate(lines):
        if method_name not in line:
            continue
        block = "\n".join(lines[i: min(i + 6, n)])
        m = METHOD_SIG_PAT.search(block)
        if m and m.group(1) == method_name:
            brace_line = None
            for j in range(i, min(i + 10, n)):
                sline = strip_string_literals(strip_inline_comment(lines[j]))
                if "{" in sline:
                    brace_line = j
                    break
            if brace_line is None:
                continue
            depth = 0
            body_lines = []
            for j in range(brace_line, n):
                sline = strip_string_literals(strip_inline_comment(lines[j]))
                for ch in sline:
                    if ch == "{":
                        depth += 1
                    elif ch == "}":
                        depth -= 1
                body_lines.append(lines[j])
                if depth == 0:
                    return "\n".join(body_lines)
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Metric computation functions
# ─────────────────────────────────────────────────────────────────────────────
def compute_cyclomatic_complexity(body: str) -> int:
    clean = re.sub(r'//[^\n]*', '', body)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
    return 1 + len(CC_PATTERN.findall(clean))

def compute_cognitive_complexity(body: str) -> int:
    score = 0
    nesting = 0
    for line in body.splitlines():
        stripped = line.strip()
        if re.search(r'\b(if|for|while|do|switch|catch)\b', stripped):
            score += 1 + nesting
            nesting += 1
        elif re.search(r'\belse\b', stripped):
            score += 1
        if stripped.startswith('}'):
            nesting = max(0, nesting - 1)
        score += len(re.findall(r'&&|\|\|', stripped))
    return score

def compute_max_nesting_depth(body: str) -> int:
    max_depth = 0
    depth = 0
    for line in body.splitlines():
        sline = strip_string_literals(strip_inline_comment(line))
        for ch in sline:
            if ch == '{':
                depth += 1
                max_depth = max(max_depth, depth)
            elif ch == '}':
                depth = max(0, depth - 1)
    return max(0, max_depth - 1)  # subtract 1 for the method's own brace

def compute_return_point_count(body: str) -> int:
    clean = re.sub(r'//[^\n]*', '', body)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
    return len(RETURN_PAT.findall(clean))

def compute_loc(body: str) -> int:
    count = 0
    in_block = False
    for line in body.splitlines():
        s = line.strip()
        if not s:
            continue
        if in_block:
            if '*/' in s:
                in_block = False
            continue
        if s.startswith('/*'):
            in_block = True
            if '*/' in s:
                in_block = False
            continue
        if s.startswith('//'):
            continue
        count += 1
    return count

def compute_statement_count(body: str) -> int:
    clean = re.sub(r'//[^\n]*', '', body)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
    clean = re.sub(r'"(?:[^"\\]|\\.)*"', '""', clean)
    return clean.count(';')

def compute_param_count(source: str, method_name: str) -> int:
    m = re.search(re.escape(method_name) + r'\s*\(([^)]*)\)', source)
    if not m:
        return 0
    params_str = m.group(1).strip()
    if not params_str:
        return 0
    depth = 0
    count = 1
    for ch in params_str:
        if ch in '<([':
            depth += 1
        elif ch in '>)]':
            depth -= 1
        elif ch == ',' and depth == 0:
            count += 1
    return count

def compute_fan_out(body: str) -> int:
    receivers = set()
    clean = re.sub(r'//[^\n]*', '', body)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
    for m in FANOUT_PATTERN.finditer(clean):
        recv = m.group(1).lower()
        if recv not in FANOUT_EXCLUDE and len(recv) > 1:
            receivers.add(recv)
    return len(receivers)

def compute_exception_count(body: str) -> int:
    exceptions = set()
    for m in CATCH_PAT.finditer(body):
        for exc in m.group(1).split('|'):
            e = exc.strip()
            if e:
                exceptions.add(e)
    return len(exceptions)

def compute_external_service_calls(body: str) -> int:
    return len(EXT_SVC_PAT.findall(body))

def compute_variable_spread(body: str) -> float:
    """
    Ratio of variables used in only one half of the method to total variables.
    High value = low cohesion.
    """
    lines = body.splitlines()
    if len(lines) < 2:
        return 0.0
    mid = len(lines) // 2
    first_half  = " ".join(lines[:mid])
    second_half = " ".join(lines[mid:])
    # Extract simple variable names (lowercase-starting identifiers)
    var_pat = re.compile(r'\b([a-z][a-zA-Z0-9_]{1,})\b')
    vars_first  = set(var_pat.findall(first_half))
    vars_second = set(var_pat.findall(second_half))
    all_vars = vars_first | vars_second
    if not all_vars:
        return 0.0
    only_one_half = len(vars_first.symmetric_difference(vars_second))
    return only_one_half / len(all_vars)

def compute_comment_density(body: str) -> float:
    lines = body.splitlines()
    if not lines:
        return 0.0
    comment_lines = 0
    total_lines = 0
    in_block = False
    for line in lines:
        s = line.strip()
        if not s:
            continue
        total_lines += 1
        if in_block:
            comment_lines += 1
            if '*/' in s:
                in_block = False
            continue
        if s.startswith('/*'):
            comment_lines += 1
            in_block = True
            if '*/' in s:
                in_block = False
            continue
        if s.startswith('//') or s.startswith('*'):
            comment_lines += 1
    if total_lines == 0:
        return 0.0
    return comment_lines / total_lines


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Extract all 15 metrics for every METHOD node
# ─────────────────────────────────────────────────────────────────────────────
def step1_extract_metrics(graph: dict) -> dict:
    print(f"\n{'='*60}")
    print("STEP 1: Extracting metrics for all METHOD nodes")
    print(f"{'='*60}")
    print(f"Graph loaded from: {GRAPH}")

    method_nodes = [n for n in graph["nodes"] if n.get("type") == "METHOD"]
    print(f"Total METHOD nodes: {len(method_nodes)}")

    # Build graph structure for fan_in / pagerank / betweenness
    print("Building NetworkX DiGraph for graph-based metrics...")
    G = nx.DiGraph()
    for node in graph["nodes"]:
        G.add_node(node["id"])
    for link in graph.get("links", graph.get("edges", [])):
        src = link.get("source", link.get("from", link.get("src", "")))
        tgt = link.get("target", link.get("to", link.get("tgt", "")))
        if src and tgt:
            G.add_edge(src, tgt)

    print(f"Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")

    # Compute graph-wide metrics (can be slow for large graphs)
    print("Computing PageRank...")
    try:
        pr = nx.pagerank(G, alpha=0.85, max_iter=500)
    except Exception as e:
        print(f"  PageRank failed: {e}, using uniform fallback")
        pr = {n: 1.0 / G.number_of_nodes() for n in G.nodes()}

    print("Computing betweenness centrality (may take a moment)...")
    try:
        bc = nx.betweenness_centrality(G, normalized=True)
    except Exception as e:
        print(f"  Betweenness failed: {e}, using zeros")
        bc = {n: 0.0 for n in G.nodes()}

    # fan_in = in-degree for each node
    in_deg = dict(G.in_degree())

    # Source file cache
    source_cache: dict[str, str] = {}

    raw: dict[str, dict] = {}
    n_source_found = 0
    n_body_extracted = 0
    n_fallback = 0

    for idx, node in enumerate(method_nodes):
        if idx > 0 and idx % 100 == 0:
            print(f"  [{idx}/{len(method_nodes)}] processed...")

        node_id    = node["id"]
        service    = node.get("service", "")
        label      = node.get("label", "")

        # Parse class.method from node_id
        short = node_id.split(":")[-1] if ":" in node_id else node_id
        if "." in short:
            class_name, method_name = short.rsplit(".", 1)
        else:
            class_name = method_name = short

        # Override from label if available
        if label and "." in label:
            cls_l, mth_l = label.rsplit(".", 1)
            if cls_l:
                class_name = cls_l
            if mth_l:
                method_name = mth_l

        # Locate source file
        cache_key = f"{service}:{class_name}"
        if cache_key not in source_cache:
            jfile = find_java_file(service, class_name)
            if jfile is not None:
                try:
                    source_cache[cache_key] = jfile.read_text(encoding="utf-8", errors="replace")
                    n_source_found += 1
                except Exception:
                    source_cache[cache_key] = ""
            else:
                source_cache[cache_key] = ""

        source = source_cache[cache_key]
        source_found = bool(source)

        body = None
        body_extracted = False
        if source:
            try:
                body = extract_method_body(source, method_name)
                if body:
                    body_extracted = True
                    n_body_extracted += 1
            except Exception:
                body = None

        # Graph metrics (always available)
        fan_in   = in_deg.get(node_id, 0)
        pg       = pr.get(node_id, 0.0)
        bt       = bc.get(node_id, 0.0)

        if body:
            try:
                cc  = compute_cyclomatic_complexity(body)
                cog = compute_cognitive_complexity(body)
                mnd = compute_max_nesting_depth(body)
                rp  = compute_return_point_count(body)
                loc = compute_loc(body)
                sc  = compute_statement_count(body)
                pc  = compute_param_count(source, method_name)
                fo  = compute_fan_out(body)
                ec  = compute_exception_count(body)
                ext = compute_external_service_calls(body)
                vs  = compute_variable_spread(body)
                cd  = compute_comment_density(body)
            except Exception:
                cc = cog = mnd = rp = loc = sc = pc = fo = ec = ext = 0
                vs = cd = 0.0
        else:
            n_fallback += 1
            cc = cog = mnd = rp = loc = sc = pc = fo = ec = ext = 0
            vs = cd = 0.0

        raw[node_id] = {
            "cyclomatic_complexity":   float(cc),
            "cognitive_complexity":    float(cog),
            "max_nesting_depth":       float(mnd),
            "return_point_count":      float(rp),
            "loc":                     float(loc),
            "statement_count":         float(sc),
            "param_count":             float(pc),
            "fan_out":                 float(fo),
            "fan_in":                  float(fan_in),
            "exception_count":         float(ec),
            "external_service_calls":  float(ext),
            "variable_spread":         float(vs),
            "comment_density":         float(cd),
            "pagerank":                float(pg),
            "betweenness_centrality":  float(bt),
            "source_found":            source_found,
            "body_extracted":          body_extracted,
        }

    print(f"\nMetrics extraction complete:")
    print(f"  Total METHOD nodes     : {len(method_nodes)}")
    print(f"  Source file found      : {n_source_found}")
    print(f"  Method body extracted  : {n_body_extracted}")
    print(f"  Using fallback values  : {n_fallback}")

    # Save raw metrics
    with open(METRICS_OUT, "w", encoding="utf-8") as f:
        json.dump(raw, f, indent=2, ensure_ascii=False, cls=NumpyEncoder)
    print(f"\nSaved raw metrics to {METRICS_OUT}")

    return raw


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Build faulty vs non-faulty classification
# ─────────────────────────────────────────────────────────────────────────────
def step2_classify_nodes(raw_metrics: dict) -> tuple[set, set]:
    print(f"\n{'='*60}")
    print("STEP 2: Classifying faulty vs non-faulty nodes")
    print(f"{'='*60}")

    with open(TEST_PATHS, encoding="utf-8") as f:
        test_paths = json.load(f)

    faulty_nodes: set[str] = set()
    for entry in test_paths:
        if entry.get("status") == "FAILING":
            fm = entry.get("faulty_method")
            if fm:
                faulty_nodes.add(fm)

    all_method_ids = set(raw_metrics.keys())
    non_faulty_nodes = all_method_ids - faulty_nodes

    # Filter faulty to those actually in the graph
    faulty_in_graph = faulty_nodes & all_method_ids
    not_in_graph    = faulty_nodes - all_method_ids
    if not_in_graph:
        print(f"  Note: {len(not_in_graph)} faulty methods not in graph (may be pruned):")
        for m in sorted(not_in_graph):
            print(f"    {m}")

    print(f"\nFaulty nodes   : {len(faulty_in_graph)}  (these are the ground truth fault locations)")
    print(f"Non-faulty nodes: {len(non_faulty_nodes)}")

    return faulty_in_graph, non_faulty_nodes


# ─────────────────────────────────────────────────────────────────────────────
# Bootstrap CI for Cliff's delta
# ─────────────────────────────────────────────────────────────────────────────
def bootstrap_cliffs_delta_ci(faulty_vals, non_faulty_vals, n_boot=2000, ci=0.95):
    np.random.seed(42)
    deltas = []
    fa = np.array(faulty_vals)
    nf = np.array(non_faulty_vals)
    for _ in range(n_boot):
        s1 = np.random.choice(fa, size=len(fa), replace=True)
        s2 = np.random.choice(nf, size=len(nf), replace=True)
        pg = np.sum(s1[:, None] > s2[None, :])
        pl = np.sum(s1[:, None] < s2[None, :])
        deltas.append((pg - pl) / (len(s1) * len(s2)))
    lower = np.percentile(deltas, (1 - ci) / 2 * 100)
    upper = np.percentile(deltas, (1 + ci) / 2 * 100)
    return lower, upper


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Statistical analysis
# ─────────────────────────────────────────────────────────────────────────────
def step3_statistical_analysis(
    raw_metrics: dict,
    faulty_nodes: set,
    non_faulty_nodes: set,
) -> dict:
    print(f"\n{'='*60}")
    print("STEP 3: Statistical analysis")
    print(f"{'='*60}")

    results = {}
    for metric in ALL_METRICS:
        faulty_values     = [raw_metrics[nid][metric] for nid in faulty_nodes     if nid in raw_metrics]
        non_faulty_values = [raw_metrics[nid][metric] for nid in non_faulty_nodes if nid in raw_metrics]

        if len(faulty_values) < 2 or len(non_faulty_values) < 2:
            continue

        fv = np.array(faulty_values, dtype=float)
        nv = np.array(non_faulty_values, dtype=float)

        faulty_mean    = float(np.mean(fv))
        non_faulty_mean = float(np.mean(nv))
        faulty_median  = float(np.median(fv))
        non_faulty_median = float(np.median(nv))

        try:
            u_stat, p_value = stats.mannwhitneyu(fv, nv, alternative="two-sided")
        except Exception:
            u_stat, p_value = 0.0, 1.0

        n1, n2 = len(fv), len(nv)
        effect_r = float(1 - (2 * u_stat) / (n1 * n2))

        try:
            pb_corr, pb_p = stats.pointbiserialr(
                [1]*n1 + [0]*n2,
                list(fv) + list(nv),
            )
        except Exception:
            pb_corr, pb_p = 0.0, 1.0

        pairs_greater = int(np.sum(fv[:, None] > nv[None, :]))
        pairs_less    = int(np.sum(fv[:, None] < nv[None, :]))
        cliffs_delta  = float((pairs_greater - pairs_less) / (n1 * n2))

        print(f"  Computing bootstrap CI for {metric}...")
        ci_lower, ci_upper = bootstrap_cliffs_delta_ci(
            list(fv), list(nv), n_boot=2000
        )

        results[metric] = {
            "faulty_mean":         faulty_mean,
            "non_faulty_mean":     non_faulty_mean,
            "faulty_median":       faulty_median,
            "non_faulty_median":   non_faulty_median,
            "n_faulty":            n1,
            "n_non_faulty":        n2,
            "u_statistic":         float(u_stat),
            "p_value":             float(p_value),
            "effect_r":            float(effect_r),
            "pb_correlation":      float(pb_corr),
            "pb_p_value":          float(pb_p),
            "cliffs_delta":        cliffs_delta,
            "cliffs_delta_ci_lower": float(ci_lower),
            "cliffs_delta_ci_upper": float(ci_upper),
            "significant":         p_value < 0.05,
            "dimension":           DIMENSION_MAP.get(metric, "Unknown"),
        }

    # Print ranked summary table
    print(f"\n{'='*60}")
    print("=== Definition A: Statistical Correlation with Fault Location ===")
    print("Sorted by absolute Cliff's delta (effect size)")
    print(f"{'='*60}")
    header = (
        f"{'Rank':>4}  {'Metric':<28} {'Faulty μ':>9} {'Non-F μ':>9} "
        f"{'p-value':>9} {'Effect r':>9} {'Cliff δ':>9} {'Sig?':>6}"
    )
    print(header)
    print("-" * len(header))

    sorted_metrics = sorted(
        results.items(),
        key=lambda x: abs(x[1]["cliffs_delta"]),
        reverse=True,
    )
    for rank, (metric, res) in enumerate(sorted_metrics, 1):
        sig = "Yes" if res["significant"] else "No"
        print(
            f"{rank:>4}  {metric:<28} {res['faulty_mean']:>9.3f} "
            f"{res['non_faulty_mean']:>9.3f} {res['p_value']:>9.4f} "
            f"{res['effect_r']:>+9.3f} {res['cliffs_delta']:>+9.3f} {sig:>6}"
        )

    print("\nNote: p < 0.05 threshold with small faulty sample has low statistical power.")
    print("Effect size (Cliff's delta) is the primary ranking criterion.")

    # Save stats
    with open(STATS_OUT, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False, cls=NumpyEncoder)
    print(f"\nSaved statistical results to {STATS_OUT}")

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Helper: collect metric arrays per group
# ─────────────────────────────────────────────────────────────────────────────
def get_arrays(raw_metrics, faulty_nodes, non_faulty_nodes, metric):
    fv = [raw_metrics[n][metric] for n in faulty_nodes     if n in raw_metrics]
    nv = [raw_metrics[n][metric] for n in non_faulty_nodes if n in raw_metrics]
    return np.array(fv, dtype=float), np.array(nv, dtype=float)


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Visualizations
# ─────────────────────────────────────────────────────────────────────────────

def plot1_correlation_heatmap(raw_metrics: dict):
    print("\n[Plot 1] Correlation heatmap...")
    node_ids = [n for n in raw_metrics if raw_metrics[n].get("source_found") is not None]
    data = np.array([[raw_metrics[n][m] for m in ALL_METRICS] for n in node_ids])

    corr_matrix = np.zeros((len(ALL_METRICS), len(ALL_METRICS)))
    for i, mi in enumerate(ALL_METRICS):
        for j, mj in enumerate(ALL_METRICS):
            try:
                r, _ = stats.spearmanr(data[:, i], data[:, j])
                corr_matrix[i, j] = r if not np.isnan(r) else 0.0
            except Exception:
                corr_matrix[i, j] = 0.0

    fig, ax = plt.subplots(figsize=(14, 12), dpi=150)
    sns.heatmap(
        corr_matrix,
        xticklabels=ALL_METRICS,
        yticklabels=ALL_METRICS,
        annot=True,
        fmt=".2f",
        cmap="RdBu_r",
        vmin=-1,
        vmax=1,
        ax=ax,
        annot_kws={"size": 7},
        linewidths=0.3,
    )
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=9)
    ax.set_title(
        "Spearman Correlation Between Code Quality Metrics (all method nodes)",
        fontsize=13, fontweight="bold", pad=15,
    )
    fig.text(
        0.5, -0.02,
        "High inter-metric correlation suggests redundancy. "
        "Metrics in the same cluster carry similar information.",
        ha="center", fontsize=9, color="gray", style="italic",
    )
    plt.tight_layout()
    path = PLOTS_DIR / "metric_correlation_heatmap.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot2_effect_size_barchart(stat_results: dict):
    print("\n[Plot 2] Effect size bar chart...")
    sorted_items = sorted(
        stat_results.items(),
        key=lambda x: abs(x[1]["cliffs_delta"]),
        reverse=True,
    )
    metrics  = [m for m, _ in sorted_items]
    deltas   = [r["cliffs_delta"] for _, r in sorted_items]
    colors   = [DIM_COLORS[DIMENSION_MAP[m]] for m in metrics]

    fig, ax = plt.subplots(figsize=(11, 8), dpi=150)
    bars = ax.barh(metrics[::-1], deltas[::-1], color=colors[::-1], edgecolor="white", height=0.6)
    ax.axvline(0, color="black", linewidth=1)
    for thresh, label, style in [
        (0.147, "small (±0.147)", "--"),
        (-0.147, "", "--"),
        (0.33, "medium (±0.33)", ":"),
        (-0.33, "", ":"),
    ]:
        ax.axvline(thresh, color="gray", linestyle=style, linewidth=1.0, alpha=0.8)
        if label:
            ax.text(thresh + 0.005, len(metrics) - 0.5, label, fontsize=7, color="gray", va="top")

    legend_patches = [
        mpatches.Patch(color=c, label=dim)
        for dim, c in DIM_COLORS.items()
    ]
    ax.legend(handles=legend_patches, loc="lower right", fontsize=9)
    ax.set_xlabel("Cliff's Delta  (positive = faulty nodes higher)", fontsize=11)
    ax.set_title(
        "Cliff's Delta Effect Size: Faulty vs Non-Faulty Method Nodes",
        fontsize=13, fontweight="bold",
    )
    ax.set_xlim(-1.05, 1.05)
    plt.tight_layout()
    path = PLOTS_DIR / "effect_size_barchart.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot3_violin_distributions(raw_metrics: dict, stat_results: dict,
                                faulty_nodes: set, non_faulty_nodes: set):
    print("\n[Plot 3] Violin distribution plots...")
    HIGH_SKEW = {"loc", "statement_count", "pagerank", "betweenness_centrality"}

    nrows, ncols = 5, 3
    fig, axes = plt.subplots(nrows, ncols, figsize=(16, 22), dpi=150)
    fig.suptitle(
        "Metric Value Distributions: Faulty vs Non-Faulty Method Nodes",
        fontsize=14, fontweight="bold", y=1.005,
    )

    import pandas as pd

    for i, metric in enumerate(ALL_METRICS):
        ax = axes[i // ncols][i % ncols]
        res = stat_results.get(metric, {})

        fv, nv = get_arrays(raw_metrics, faulty_nodes, non_faulty_nodes, metric)

        # Check if log scale needed
        use_log = (metric in HIGH_SKEW) or (
            len(nv) > 0 and np.max(nv) > 0 and np.max(nv) / (np.mean(nv) + 1e-9) > 10
        )

        df_f = pd.DataFrame({"value": fv, "group": "Faulty"})
        df_n = pd.DataFrame({"value": nv, "group": "Non-Faulty"})
        df   = pd.concat([df_f, df_n], ignore_index=True)

        # Log-transform if needed
        if use_log:
            df["value"] = np.log1p(df["value"])
            ylabel = f"{metric} (log1p)"
        else:
            ylabel = metric

        palette = {"Faulty": FAULTY_COLOR, "Non-Faulty": NON_FAULTY_COLOR}
        try:
            sns.violinplot(data=df, x="group", y="value", palette=palette, ax=ax,
                           inner=None, cut=0, alpha=0.7)
            sns.stripplot(data=df, x="group", y="value", palette=palette, ax=ax,
                          size=3, alpha=0.4, jitter=0.1)
        except Exception:
            sns.boxplot(data=df, x="group", y="value", palette=palette, ax=ax)

        # Median lines
        for j, (grp, gdf) in enumerate(df.groupby("group")):
            med = gdf["value"].median()
            ax.axhline(med, color=palette[grp], linestyle="--", linewidth=1.2,
                       xmin=j * 0.5 + 0.05, xmax=j * 0.5 + 0.45,
                       label=f"{grp} median")

        # Annotation
        p_val = res.get("p_value", 1.0)
        cd    = res.get("cliffs_delta", 0.0)
        p_str = f"p={p_val:.4f}" if p_val >= 0.0001 else "p<0.0001"
        ax.text(0.97, 0.97, f"{p_str}\nδ={cd:+.3f}",
                transform=ax.transAxes, ha="right", va="top",
                fontsize=8, bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.7))

        ax.set_title(metric, fontsize=10, fontweight="bold")
        ax.set_xlabel("")
        ax.set_ylabel(ylabel if use_log else "", fontsize=8)

    # Hide unused subplots
    for j in range(len(ALL_METRICS), nrows * ncols):
        axes[j // ncols][j % ncols].set_visible(False)

    plt.tight_layout()
    path = PLOTS_DIR / "metric_distributions_violin.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot4_importance_dotplot(stat_results: dict):
    print("\n[Plot 4] Importance dot plot...")
    sorted_items = sorted(
        stat_results.items(),
        key=lambda x: abs(x[1]["cliffs_delta"]),
        reverse=True,
    )

    metrics = [m for m, _ in sorted_items]
    deltas  = [r["cliffs_delta"] for _, r in sorted_items]
    ci_lo   = [r["cliffs_delta_ci_lower"] for _, r in sorted_items]
    ci_hi   = [r["cliffs_delta_ci_upper"] for _, r in sorted_items]
    sigs    = [r["significant"] for _, r in sorted_items]
    dims    = [DIMENSION_MAP[m] for m in metrics]

    y_pos  = list(range(len(metrics)))
    fig, ax = plt.subplots(figsize=(11, 9), dpi=150)

    for i, (m, d, lo, hi, sig, dim) in enumerate(
        zip(metrics, deltas, ci_lo, ci_hi, sigs, dims)
    ):
        color = DIM_COLORS[dim]
        ax.plot([0, d], [i, i], color=color, linewidth=1.5, alpha=0.7)
        err_lo = d - lo
        err_hi = hi - d
        marker = "o" if sig else "o"
        fill   = "full" if sig else "none"
        ax.errorbar(
            d, i, xerr=[[err_lo], [err_hi]],
            fmt=marker, color=color, fillstyle=fill,
            markersize=10, capsize=4, linewidth=1.2, elinewidth=1.2,
        )

    ax.axvline(0, color="black", linewidth=1)
    for thresh in [0.147, -0.147, 0.33, -0.33]:
        ax.axvline(thresh, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(
        [f"{m}" for m in metrics],
        fontsize=10,
    )
    # Color y-tick labels by dimension
    for tick, dim in zip(ax.get_yticklabels(), dims):
        tick.set_color(DIM_COLORS[dim])

    # Legend: dimension + significance
    dim_patches = [mpatches.Patch(color=c, label=d) for d, c in DIM_COLORS.items()]
    sig_patch   = mpatches.Patch(color="gray", label="filled = p<0.05")
    ax.legend(handles=dim_patches + [sig_patch], loc="lower right", fontsize=8)

    ax.set_xlabel("Cliff's Delta (95% bootstrap CI)", fontsize=11)
    ax.set_title(
        "Metric Importance Ranking — Definition A:\nStatistical Correlation with Fault Location",
        fontsize=12, fontweight="bold",
    )
    ax.set_xlim(-1.1, 1.1)
    plt.tight_layout()
    path = PLOTS_DIR / "importance_dotplot.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot5_top5_pairplot(raw_metrics: dict, stat_results: dict,
                         faulty_nodes: set, non_faulty_nodes: set):
    print("\n[Plot 5] Top-5 pairplot...")
    import pandas as pd

    sorted_metrics = sorted(
        stat_results.items(),
        key=lambda x: abs(x[1]["cliffs_delta"]),
        reverse=True,
    )
    top5 = [m for m, _ in sorted_metrics[:5]]
    print(f"  Top-5 metrics: {top5}")

    rows = []
    for nid in faulty_nodes:
        if nid in raw_metrics:
            row = {m: raw_metrics[nid][m] for m in top5}
            row["Fault Status"] = "Faulty"
            rows.append(row)
    for nid in non_faulty_nodes:
        if nid in raw_metrics:
            row = {m: raw_metrics[nid][m] for m in top5}
            row["Fault Status"] = "Non-Faulty"
            rows.append(row)

    df = pd.DataFrame(rows)

    palette = {"Faulty": FAULTY_COLOR, "Non-Faulty": NON_FAULTY_COLOR}
    try:
        g = sns.pairplot(
            df,
            hue="Fault Status",
            vars=top5,
            palette=palette,
            diag_kind="kde",
            plot_kws={"alpha": 0.4, "s": 20},
            height=2.5,
        )
        g.figure.suptitle(
            "Pairwise Relationships: Top-5 Most Fault-Correlated Metrics",
            y=1.02, fontsize=12, fontweight="bold",
        )
        path = PLOTS_DIR / "top5_pairplot.png"
        g.figure.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(g.figure)
    except Exception as e:
        print(f"  Pairplot failed ({e}), saving simple scatter instead.")
        fig, ax = plt.subplots(figsize=(10, 8), dpi=150)
        ax.set_title("Top-5 pairplot unavailable")
        path = PLOTS_DIR / "top5_pairplot.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    print(f"  Saved: {path}")


def plot6_radar_chart(stat_results: dict):
    print("\n[Plot 6] Dimension radar chart...")
    dimensions = list(DIM_COLORS.keys())
    N = len(dimensions)

    def dim_max_delta(dim):
        vals = [
            abs(r["cliffs_delta"])
            for m, r in stat_results.items()
            if DIMENSION_MAP.get(m) == dim
        ]
        return max(vals) if vals else 0.0

    def dim_sig_prop(dim):
        items = [
            r for m, r in stat_results.items()
            if DIMENSION_MAP.get(m) == dim
        ]
        if not items:
            return 0.0
        return sum(1 for r in items if r["significant"]) / len(items)

    delta_vals = [dim_max_delta(d) for d in dimensions]
    sig_vals   = [dim_sig_prop(d) for d in dimensions]

    # Close the radar
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]
    delta_vals_ = delta_vals + delta_vals[:1]
    sig_vals_   = sig_vals   + sig_vals[:1]

    fig, ax = plt.subplots(figsize=(8, 8), dpi=150, subplot_kw=dict(polar=True))
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(dimensions, fontsize=11)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(["0.2", "0.4", "0.6", "0.8", "1.0"], fontsize=8)
    ax.set_rlabel_position(180 / N)

    ax.plot(angles, delta_vals_, linewidth=2, linestyle="solid", color="#E74C3C",
            label="Max |Cliff's δ| per dimension")
    ax.fill(angles, delta_vals_, alpha=0.2, color="#E74C3C")

    ax.plot(angles, sig_vals_, linewidth=2, linestyle="dashed", color="#3498DB",
            label="Prop. significant (p<0.05)")
    ax.fill(angles, sig_vals_, alpha=0.15, color="#3498DB")

    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.1), fontsize=9)
    ax.set_title("Fault Correlation by Metric Dimension",
                 fontsize=13, fontweight="bold", pad=20)

    path = PLOTS_DIR / "dimension_radar.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Print and save interpretation
# ─────────────────────────────────────────────────────────────────────────────
def step5_interpretation(raw_metrics: dict, stat_results: dict):
    print(f"\n{'='*60}")
    print("=== INTERPRETATION GUIDE ===")
    print(f"{'='*60}")

    # Sorted by |delta|
    sorted_items = sorted(
        stat_results.items(),
        key=lambda x: abs(x[1]["cliffs_delta"]),
        reverse=True,
    )

    # High effect size
    high_effect = [(m, r) for m, r in sorted_items if abs(r["cliffs_delta"]) > 0.15]
    print("\nTop metrics by effect size (|Cliff's delta| > 0.15):")
    if high_effect:
        for m, r in high_effect:
            print(f"  {m:<30} delta={r['cliffs_delta']:+.3f}")
    else:
        print("  None found above 0.15 threshold")

    # Statistically significant
    sig_metrics = [(m, r) for m, r in sorted_items if r["significant"]]
    print("\nMetrics with statistical significance (p < 0.05):")
    if sig_metrics:
        for m, r in sig_metrics:
            print(f"  {m:<30} p={r['p_value']:.4f}")
    else:
        print("  None (low power due to small faulty sample)")

    # Highly correlated pairs
    all_ids = list(raw_metrics.keys())
    data_arr = np.array([[raw_metrics[n][m] for m in ALL_METRICS] for n in all_ids])
    redundant_pairs = []
    for i, mi in enumerate(ALL_METRICS):
        for j, mj in enumerate(ALL_METRICS):
            if j <= i:
                continue
            try:
                r, _ = stats.spearmanr(data_arr[:, i], data_arr[:, j])
                if abs(r) > 0.7:
                    redundant_pairs.append((mi, mj, r))
            except Exception:
                pass

    print("\nMetrics highly correlated with each other (Spearman r > 0.7):")
    if redundant_pairs:
        for mi, mj, r in sorted(redundant_pairs, key=lambda x: -abs(x[2])):
            print(f"  {mi} ↔ {mj}  r={r:.3f}")
    else:
        print("  None found")

    # Recommendation: non-redundant high-signal metrics
    print("\nRecommended metric subset for GNN node features:")
    seen_redundant_groups = []
    recommended = []
    for m, r in sorted_items:
        if abs(r["cliffs_delta"]) < 0.05 and not r["significant"]:
            continue  # too weak
        # Check redundancy with already-selected metrics
        is_redundant = False
        for sel in recommended:
            # find if (m, sel) or (sel, m) is in redundant_pairs
            for mi, mj, rr in redundant_pairs:
                if {mi, mj} == {m, sel}:
                    is_redundant = True
                    break
            if is_redundant:
                break
        if not is_redundant:
            recommended.append(m)

    if recommended:
        for m in recommended:
            r = stat_results[m]
            print(f"  {m:<30} delta={r['cliffs_delta']:+.3f}  p={r['p_value']:.4f}")
    else:
        print("  (No metrics passed threshold — use all 15 or top-by-delta)")

    # Dimensions ranked
    print("\nDimensions ranked by maximum absolute effect size:")
    dim_max = {}
    for m, r in stat_results.items():
        dim = DIMENSION_MAP.get(m, "Unknown")
        delta = abs(r["cliffs_delta"])
        if dim not in dim_max or delta > dim_max[dim]:
            dim_max[dim] = delta
    for rank, (dim, val) in enumerate(
        sorted(dim_max.items(), key=lambda x: -x[1]), 1
    ):
        print(f"  {rank}. {dim:<20} delta = {val:.3f}")

    # Build text
    lines = []
    lines.append("=== INTERPRETATION GUIDE ===\n")
    lines.append("Top metrics by effect size (|Cliff's delta| > 0.15):")
    for m, r in high_effect:
        lines.append(f"  {m:<30} delta={r['cliffs_delta']:+.3f}")
    if not high_effect:
        lines.append("  None found above 0.15 threshold")

    lines.append("\nMetrics with statistical significance (p < 0.05):")
    for m, r in sig_metrics:
        lines.append(f"  {m:<30} p={r['p_value']:.4f}")
    if not sig_metrics:
        lines.append("  None (low power due to small faulty sample)")

    lines.append("\nMetrics highly correlated (Spearman r > 0.7 — redundant pairs):")
    for mi, mj, r in sorted(redundant_pairs, key=lambda x: -abs(x[2])):
        lines.append(f"  {mi} <-> {mj}  r={r:.3f}")
    if not redundant_pairs:
        lines.append("  None found")

    lines.append("\nRecommended metric subset for GNN node features:")
    for m in recommended:
        r = stat_results[m]
        lines.append(f"  {m:<30} delta={r['cliffs_delta']:+.3f}  p={r['p_value']:.4f}")
    if not recommended:
        lines.append("  (No metrics passed threshold — use all 15 or top-by-delta)")

    lines.append("\nDimensions ranked by maximum absolute effect size:")
    for rank, (dim, val) in enumerate(
        sorted(dim_max.items(), key=lambda x: -x[1]), 1
    ):
        lines.append(f"  {rank}. {dim:<20} delta = {val:.3f}")

    interpretation_text = "\n".join(lines)
    with open(INTERP_OUT, "w", encoding="utf-8") as f:
        f.write(interpretation_text)
    print(f"\nSaved interpretation to {INTERP_OUT}")

    return recommended, dim_max


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print(f"Loading graph from: {GRAPH}")
    with open(GRAPH, encoding="utf-8") as f:
        graph = json.load(f)

    # STEP 1
    raw_metrics = step1_extract_metrics(graph)

    # STEP 2
    faulty_nodes, non_faulty_nodes = step2_classify_nodes(raw_metrics)

    # STEP 3
    stat_results = step3_statistical_analysis(raw_metrics, faulty_nodes, non_faulty_nodes)

    # STEP 4 — all 6 plots
    print(f"\n{'='*60}")
    print("STEP 4: Generating visualizations")
    print(f"{'='*60}")

    plot1_correlation_heatmap(raw_metrics)
    plot2_effect_size_barchart(stat_results)
    plot3_violin_distributions(raw_metrics, stat_results, faulty_nodes, non_faulty_nodes)
    plot4_importance_dotplot(stat_results)
    plot5_top5_pairplot(raw_metrics, stat_results, faulty_nodes, non_faulty_nodes)
    plot6_radar_chart(stat_results)

    # STEP 5
    step5_interpretation(raw_metrics, stat_results)

    n_faulty     = len(faulty_nodes)
    n_non_faulty = len(non_faulty_nodes)
    n_total      = n_faulty + n_non_faulty
    print(
        f"\nAnalysis complete: {len(ALL_METRICS)} metrics analyzed across "
        f"{n_total} nodes ({n_faulty} faulty, {n_non_faulty} non-faulty). "
        f"Results saved to {STATS_OUT}"
    )


if __name__ == "__main__":
    main()
