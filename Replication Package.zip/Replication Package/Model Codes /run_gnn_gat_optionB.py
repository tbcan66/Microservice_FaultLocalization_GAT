#!/usr/bin/env python3
"""
Option B: Proper PyTorch Geometric GAT GNN for Fault Localization

Architecture:
  - GAT (Graph Attention Network) — learns per-edge attention weights
  - Rich node features: Ochiai, in/out degree, node type, is_controller, etc.
  - Edge attributes: type-encoded weight passed to GATConv (edge_dim=1)
  - Training objective: node is faulty (binary) given labeled ground truth

Training strategy:
  - We have 26 labeled faults (one per failing test)
  - Direct supervised: train on all labeled nodes, predict suspiciousness
  - Evaluation: for each failing test, rank the nodes it covers, check rank of faulty node
  - LOO (leave-one-out) not needed here because we're evaluating ranking, not predicting labels

Run with:
  /User_Path/.venv/bin/python3 run_gnn_optionB.py
"""

import json
import math
from collections import defaultdict
from pathlib import Path

import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GATConv

ROOT = Path("/User_Path/train-ticket-with-test-suites-1.0.0")

# ── Configuration ─────────────────────────────────────────────────────────────
EPOCHS      = 300
LR          = 0.005
HIDDEN      = 32
HEADS       = 4
DROPOUT     = 0.2

EDGE_TYPE_MAP = {
    "TEST_RUNS_ON":  1.0,
    "TEST_COVERS":   0.8,
    "CALLS":         0.7,
    "CALLS_REPO":    0.6,
    "HTTP_CALL":     0.5,
    "CALLS_LOCAL":   0.35,
    "DEFAULT":       0.5,
}

NODE_TYPE_MAP = {"TEST": 0.0, "SERVICE": 0.25, "API": 0.5, "METHOD": 0.75, "CONTROLLER": 1.0}


# ── Helpers ───────────────────────────────────────────────────────────────────
def compute_ochiai(tests, cover_field):
    nf = sum(1 for t in tests if t["status"] == "FAILING")
    ef = defaultdict(int)
    ep = defaultdict(int)
    for t in tests:
        for nid in t.get(cover_field, []):
            if t["status"] == "FAILING": ef[nid] += 1
            else:                        ep[nid] += 1
    scores = {}
    for nid in set(ef) | set(ep):
        denom = math.sqrt(nf * (ef[nid] + ep[nid]))
        scores[nid] = ef[nid] / denom if denom else 0.0
    return scores, ef, ep


def top_k_accuracy(tests, cover_field, faulty_field, scores, k_values=(1, 3, 5)):
    failing_with_gt = [t for t in tests if t["status"] == "FAILING" and t.get(faulty_field)]
    hits = defaultdict(int)
    ranks_out = []
    for t in failing_with_gt:
        faulty  = t[faulty_field]
        covered = t.get(cover_field, [])
        if not covered:
            ranks_out.append((t["test_id"], faulty, None))
            continue
        ranked = sorted(covered, key=lambda n: -scores.get(n, 0.0))
        rank   = ranked.index(faulty) + 1 if faulty in ranked else None
        ranks_out.append((t["test_id"], faulty, rank))
        for k in k_values:
            if faulty in ranked[:k]:
                hits[k] += 1
    total = len(failing_with_gt)
    return {k: (hits[k] / total if total else 0.0) for k in k_values}, total, ranks_out


# ── Build PyG Data object ─────────────────────────────────────────────────────
def build_pyg_data(tests, cover_field, faulty_field,
                   infra_ids, infra_type_label,
                   edges_with_types):
    """
    Builds a PyG Data object where each node is either a test or infrastructure node.
    
    Node features (12-dim):
      [0]  is_failing_test       (1.0 / 0.0)
      [1]  is_passing_test       (1.0 / 0.0)
      [2]  is_infra              (1.0 / 0.0)
      [3]  ochiai_score          (float)
      [4]  n_failing_covering    (normalised)
      [5]  n_passing_covering    (normalised)
      [6]  in_degree             (normalised)
      [7]  node_type_encoding    (0=test, 0.25=service, 0.5=api, 0.75=method, 1.0=ctrl)
      [8]  cyclomatic_complexity (normalised, from code_metrics.json)
      [9]  loc                   (normalised)
      [10] fan_out               (normalised)
      [11] param_count           (normalised)
    
    Labels (for training):
      1.0 if the node is the ground-truth faulty node for any failing test
      0.0 otherwise
    """
    # Load code quality metrics (silently skip if file not yet computed)
    code_metrics: dict = {}
    metrics_path = ROOT / "code_metrics.json"
    if metrics_path.exists():
        with open(metrics_path) as _f:
            code_metrics = json.load(_f)

    ochiai, ef, ep = compute_ochiai(tests, cover_field)
    nf_total = sum(1 for t in tests if t["status"] == "FAILING")
    np_total = sum(1 for t in tests if t["status"] == "PASSING")

    # Ground truth faulty nodes
    faulty_nodes = {t[faulty_field] for t in tests if t.get(faulty_field)}

    test_ids    = {t["test_id"] for t in tests}
    failing_ids = {t["test_id"] for t in tests if t["status"] == "FAILING"}

    all_ids = list(test_ids | infra_ids)
    idx_map = {nid: i for i, nid in enumerate(all_ids)}

    # Compute in-degree
    in_deg = defaultdict(int)
    for src, tgt, _ in edges_with_types:
        in_deg[tgt] += 1
    max_in = max(in_deg.values(), default=1)

    # Build feature matrix
    _METRIC_FALLBACK_INFRA = [0.0, 1.0, 0.0, 0.0]  # non-METHOD infra fallback
    _METRIC_FALLBACK_TEST  = [0.0, 1.0, 0.0, 0.0]  # test node fallback

    feats = []
    labels = []
    for nid in all_ids:
        is_fail = 1.0 if nid in failing_ids else 0.0
        is_pass = 1.0 if (nid in test_ids and nid not in failing_ids) else 0.0
        is_inf  = 1.0 if nid in infra_ids else 0.0
        oc      = ochiai.get(nid, 0.0)
        n_ef    = ef.get(nid, 0) / max(nf_total, 1)
        n_ep    = ep.get(nid, 0) / max(np_total, 1)
        indeg   = in_deg.get(nid, 0) / max_in
        ntype   = NODE_TYPE_MAP.get(infra_type_label if nid in infra_ids else "TEST", 0.0)

        # Code quality metrics (4 dims) — METHOD infra nodes only
        if nid in infra_ids and infra_type_label == "METHOD":
            m = code_metrics.get(nid, {})
            code_feat = [
                m.get("complexity",  0.0),
                m.get("loc",         1.0),
                m.get("fan_out",     0.0),
                m.get("param_count", 0.0),
            ]
        elif nid in infra_ids:
            code_feat = _METRIC_FALLBACK_INFRA
        else:
            code_feat = _METRIC_FALLBACK_TEST

        feats.append([is_fail, is_pass, is_inf, oc, n_ef, n_ep, indeg, ntype] + code_feat)

        # Label: 1 if this is a known faulty infrastructure node
        label = 1.0 if (nid in faulty_nodes and nid in infra_ids) else 0.0
        labels.append(label)

    x      = torch.tensor(feats, dtype=torch.float)
    y      = torch.tensor(labels, dtype=torch.float)

    # Build edge index + edge attr
    edge_list  = []
    edge_attrs = []
    for src, tgt, etype in edges_with_types:
        if src in idx_map and tgt in idx_map:
            edge_list.append([idx_map[src], idx_map[tgt]])
            # Add reverse edges for bidirectional signal propagation
            edge_list.append([idx_map[tgt], idx_map[src]])
            w = EDGE_TYPE_MAP.get(etype, EDGE_TYPE_MAP["DEFAULT"])
            edge_attrs.append([w])
            edge_attrs.append([w * 0.5])  # reverse edges half weight

    edge_index = torch.tensor(edge_list, dtype=torch.long).t().contiguous() if edge_list else torch.zeros((2, 0), dtype=torch.long)
    edge_attr  = torch.tensor(edge_attrs, dtype=torch.float) if edge_attrs else torch.zeros((0, 1), dtype=torch.float)

    # Training mask: only infra nodes with known labels (faulty or covered by tests)
    train_nodes = {nid for t in tests for nid in t.get(cover_field, [])} | faulty_nodes
    train_mask  = torch.tensor([nid in train_nodes and nid in infra_ids for nid in all_ids])

    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y, train_mask=train_mask), idx_map, all_ids


# ── GAT Model ─────────────────────────────────────────────────────────────────
class FaultLocGAT(torch.nn.Module):
    """
    Graph Attention Network for fault localization.
    in_features=12: 8 base features + 4 code-quality metrics
      (cyclomatic_complexity, loc, fan_out, param_count)
    """
    def __init__(self, in_features=12, hidden=HIDDEN, heads=HEADS, dropout=DROPOUT):
        super().__init__()
        self.conv1 = GATConv(in_features, hidden, heads=heads, edge_dim=1, dropout=dropout)
        self.conv2 = GATConv(hidden * heads, hidden, heads=1,  edge_dim=1, dropout=dropout)
        self.out   = torch.nn.Linear(hidden, 1)
        self.dropout = dropout

    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv1(x, edge_index, edge_attr)
        x = F.elu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv2(x, edge_index, edge_attr)
        x = F.elu(x)
        return torch.sigmoid(self.out(x)).squeeze(-1)


# ── Train + Predict ─────────────────────────────────────────────────────────
def train_and_predict(data, idx_map, all_ids, infra_ids, epochs=EPOCHS, lr=LR):
    model     = FaultLocGAT()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    # Positive class weight for imbalanced labels (few faulty, many clean)
    n_pos = data.y[data.train_mask].sum().item()
    n_neg = data.train_mask.sum().item() - n_pos
    pos_weight = torch.tensor([max(n_neg / max(n_pos, 1), 1.0)])

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out  = model(data)
        pred = out[data.train_mask]
        true = data.y[data.train_mask]
        loss = F.binary_cross_entropy(pred, true,
                                       weight=pos_weight.expand_as(true) * true + (1 - true))
        loss.backward()
        optimizer.step()
        if (epoch + 1) % 100 == 0:
            print(f"    epoch {epoch+1:3d}/{epochs}  loss={loss.item():.4f}")

    model.eval()
    with torch.no_grad():
        scores_tensor = model(data).numpy()

    return {nid: float(scores_tensor[i]) for i, nid in enumerate(all_ids) if nid in infra_ids}


# ══════════════════════════════════════════════════════════════════════════════
# Per-level runners
# ══════════════════════════════════════════════════════════════════════════════
def build_edges_l1(tests, service_ids):
    edges = []
    for t in tests:
        tid, src = t["test_id"], t["source_service"]
        if src in service_ids:
            edges.append((tid, src, "TEST_RUNS_ON"))
        for svc in t.get("path", []):
            if svc in service_ids and svc != src:
                edges.append((tid, svc, "TEST_COVERS"))
    with open(ROOT / "level1_service_graph.json") as f:
        g1 = json.load(f)
    for lnk in g1["links"]:
        edges.append((lnk["source"], lnk["target"], "CALLS"))
    return edges


def build_edges_l2(tests, api_ids):
    edges = []
    for t in tests:
        tid  = t["test_id"]
        entry = t.get("entry_point_api")
        if entry and entry in api_ids:
            edges.append((tid, entry, "TEST_RUNS_ON"))
        for d in t.get("downstream_apis", []):
            aid = d["api_id"]
            if aid in api_ids:
                edges.append((tid, aid, "TEST_COVERS"))
    with open(ROOT / "level2_api_graph.json") as f:
        g2 = json.load(f)
    for lnk in g2["links"]:
        rel = lnk.get("relation", "HTTP_CALL")
        edges.append((lnk["source"], lnk["target"], rel if rel in EDGE_TYPE_MAP else "HTTP_CALL"))
    return edges


def build_edges_l3(tests, method_ids):
    edges = []
    for t in tests:
        tid   = t["test_id"]
        entry = t.get("entry_controller_method")
        if entry and entry in method_ids:
            edges.append((tid, entry, "TEST_RUNS_ON"))
        for rm in t.get("reachable_methods", []):
            mid = rm["method_id"]
            if mid in method_ids:
                edges.append((tid, mid, "TEST_COVERS"))
    with open(ROOT / "level3_method_graph.json") as f:
        g3 = json.load(f)
    for lnk in g3["links"]:
        rel = lnk.get("relation", "CALLS")
        edges.append((lnk["source"], lnk["target"], rel if rel in EDGE_TYPE_MAP else "CALLS"))
    return edges


def run_level(name, tests_file, cover_field, faulty_field,
              infra_ids, infra_type, edges):
    print(f"\n{'='*60}")
    print(f"  {name}")
    print(f"{'='*60}")
    with open(tests_file) as f:
        tests = json.load(f)

    data, idx_map, all_ids = build_pyg_data(
        tests, cover_field, faulty_field, infra_ids, infra_type, edges
    )
    print(f"  Nodes: {len(all_ids)}  |  Edges: {data.edge_index.shape[1]}")
    print(f"  Training nodes: {data.train_mask.sum().item()}")
    print(f"  Faulty nodes (labels=1): {int(data.y.sum().item())}")

    print(f"  Training GAT ({EPOCHS} epochs)...")
    scores = train_and_predict(data, idx_map, all_ids, infra_ids)

    acc, n, ranks = top_k_accuracy(tests, cover_field, faulty_field, scores)
    return acc, n, scores, ranks, name, infra_ids


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 70)
    print("Option B: PyTorch GAT GNN — Fault Localization")
    print(f"PyTorch {torch.__version__} | Epochs={EPOCHS} | Hidden={HIDDEN} | Heads={HEADS}")
    print("=" * 70)

    # Load graph structures
    with open(ROOT / "level1_service_graph.json") as f:
        g1 = json.load(f)
    with open(ROOT / "level2_api_graph.json") as f:
        g2 = json.load(f)
    with open(ROOT / "level3_method_graph.json") as f:
        g3 = json.load(f)

    svc_ids    = {n["id"] for n in g1["nodes"]}
    api_ids    = {n["id"] for n in g2["nodes"] if n.get("type") == "API"}
    method_ids = {n["id"] for n in g3["nodes"] if n.get("type") == "METHOD"}

    with open(ROOT / "test_service_paths.json") as f:
        t1 = json.load(f)
    with open(ROOT / "test_api_paths.json") as f:
        t2 = json.load(f)
    with open(ROOT / "test_method_paths.json") as f:
        t3 = json.load(f)

    levels = [
        ("L1 Service",       ROOT/"test_service_paths.json", "path",        "faulty_service", svc_ids,    "SERVICE",    build_edges_l1(t1, svc_ids)),
        ("L2 API Endpoint",  ROOT/"test_api_paths.json",    "api_path",    "faulty_api",     api_ids,    "API",        build_edges_l2(t2, api_ids)),
        ("L3 Java Method",   ROOT/"test_method_paths.json", "method_path", "faulty_method",  method_ids, "METHOD",     build_edges_l3(t3, method_ids)),
    ]

    results = []
    for name, tfile, cfield, ffield, infra, itype, edges in levels:
        acc, n, scores, ranks, label, iids = run_level(name, tfile, cfield, ffield, infra, itype, edges)
        results.append((label, acc, n, scores, ranks, iids))

    # ── Summary ──────────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("RESULTS — GAT GNN (Option B)")
    print("=" * 70)
    print(f"\n{'Level':<22} {'Tests':>6} {'Top-1':>8} {'Top-3':>8} {'Top-5':>8}")
    print("-" * 56)
    for label, acc, n, _, _, _ in results:
        print(f"{label:<22} {n:>6} {acc[1]:>7.1%} {acc[3]:>8.1%} {acc[5]:>8.1%}")

    print("\n--- Top-10 Suspicious Nodes per Level ---")
    for label, acc, n, scores, ranks, infra_ids in results:
        print(f"\n{label}:")
        top10 = sorted(
            [(nid, sc) for nid, sc in scores.items() if nid in infra_ids],
            key=lambda x: -x[1]
        )[:10]
        for i, (nid, sc) in enumerate(top10, 1):
            print(f"  {i:2}. [{sc:.4f}]  {nid}")

    print("\n--- Per-Failing-Test: Rank of Faulty Node ---")
    for label, acc, n, scores, ranks, _ in results:
        lvl = label.split()[0]
        for entry in ranks:
            if entry is None: continue
            tid, faulty, rank = entry
            method = tid.split(".")[-1] if "." in tid else tid
            rank_s = str(rank) if rank else "N/A"
            faulty_s = faulty[-50:] if len(faulty) > 50 else faulty
            print(f"  [{lvl}] {method[:42]:<43}  rank={rank_s:>4}  {faulty_s}")
        print()

    # Save
    out_data = {}
    for label, acc, n, scores, ranks, infra_ids in results:
        top30 = sorted(
            [(nid, sc) for nid, sc in scores.items() if nid in infra_ids],
            key=lambda x: -x[1]
        )[:30]
        out_data[label] = {
            "algorithm": "GAT_OptionB",
            "top_1": round(acc[1], 4), "top_3": round(acc[3], 4), "top_5": round(acc[5], 4),
            "n_failing_tested": n,
            "top_30_nodes": [{"node": nid, "score": round(sc, 6)} for nid, sc in top30]
        }

    out = ROOT / "gnn_results_optionB.json"
    with open(out, "w") as f:
        json.dump(out_data, f, indent=2)
    print(f"\n✅  Saved → {out}")
