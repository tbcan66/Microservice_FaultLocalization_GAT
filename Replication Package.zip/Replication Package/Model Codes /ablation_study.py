#!/usr/bin/env python3
"""
ablation_study.py
=================
Systematic ablation study: which code quality metrics contribute most to
GAT GNN fault localization accuracy at the L3 (method) level?

19 configurations × 10 seeds × 300 epochs.
Results saved to output/ablation_results.json + output/plots/ablation_*.png

Imports reusable helpers from run_gnn_optionB.py without modifying it.
"""

import json
import math
import random
import time
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GATConv
from scipy.stats import spearmanr

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

# ── Paths ──────────────────────────────────────────────────────────────────────
ROOT = Path(
    "/User_Path/"
    "Dataset/train-ticket-with-test-suites-1.0.0"
)
sys.path.insert(0, str(ROOT))

# Graph file — prefer pruned, fall back to full
_GRAPH_PRUNED = ROOT / "output" / "level3_method_graph_pruned.json"
_GRAPH_FULL   = ROOT / "level3_method_graph.json"
GRAPH_PATH    = _GRAPH_PRUNED if _GRAPH_PRUNED.exists() else _GRAPH_FULL

TESTS_PATH    = ROOT / "test_method_paths.json"
METRICS_PATH  = ROOT / "output" / "code_metrics_full.json"
STATS_PATH    = ROOT / "output" / "metric_importance_stats.json"
OUTPUT_DIR    = ROOT / "output"
PLOTS_DIR     = OUTPUT_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

# ── Import reusable helpers from run_gnn_optionB ───────────────────────────────
from run_gnn_optionB import (
    compute_ochiai,
    top_k_accuracy,
    EDGE_TYPE_MAP,
    NODE_TYPE_MAP,
)

# ── Training hyperparameters ───────────────────────────────────────────────────
N_SEEDS = 10
EPOCHS  = 300
LR      = 0.005
HIDDEN  = 32
HEADS   = 4
DROPOUT = 0.2

# Noise patterns to exclude from L3 node set (same as optionB_fixed)
NOISE_PATTERNS = [
    ".fallback", ".ok", ".home", ".welcome",
    ".BCryptPasswordEncoder", ".WebMvcConfigurerAdapter",
    ".JWTFilter", ".restTemplate",
]

# Definition A Cliff's delta values for the 6 ablated metrics (from analysis)
DEFA_DELTA = {
    "betweenness_centrality": 0.973,
    "cyclomatic_complexity":  0.932,
    "fan_out":                0.912,
    "loc":                    0.908,
    "param_count":            0.815,
    "fan_in":                 0.617,
}
DEFA_RANK = {
    "betweenness_centrality": 1,
    "cyclomatic_complexity":  3,
    "fan_out":                5,
    "loc":                    6,
    "param_count":            8,
    "fan_in":                 10,
}

# ── Ablation configurations ────────────────────────────────────────────────────
CONFIGS = {
    # ── Baseline configurations
    "00_no_metrics": {
        "description": "No metrics — base 8 features only, edge_dim=1",
        "node_metrics": [],
        "edge_metrics":  [],
    },
    "01_all_metrics": {
        "description": "All 6 metrics as node features + edge diffs (Option 1 full)",
        "node_metrics": ["betweenness_centrality", "cyclomatic_complexity",
                         "fan_out", "loc", "param_count", "fan_in"],
        "edge_metrics":  ["cyclomatic_complexity", "loc",
                          "fan_out", "betweenness_centrality"],
    },

    # ── Single metric ablations
    "02_only_betweenness": {
        "description": "Only betweenness_centrality (Definition A rank 1)",
        "node_metrics": ["betweenness_centrality"],
        "edge_metrics":  ["betweenness_centrality"],
    },
    "03_only_cyclomatic": {
        "description": "Only cyclomatic_complexity (Definition A rank 3)",
        "node_metrics": ["cyclomatic_complexity"],
        "edge_metrics":  ["cyclomatic_complexity"],
    },
    "04_only_fan_out": {
        "description": "Only fan_out (Definition A rank 5)",
        "node_metrics": ["fan_out"],
        "edge_metrics":  ["fan_out"],
    },
    "05_only_loc": {
        "description": "Only loc (Definition A rank 6)",
        "node_metrics": ["loc"],
        "edge_metrics":  ["loc"],
    },
    "06_only_param_count": {
        "description": "Only param_count (Definition A rank 8)",
        "node_metrics": ["param_count"],
        "edge_metrics":  [],
    },
    "07_only_fan_in": {
        "description": "Only fan_in (Definition A rank 10)",
        "node_metrics": ["fan_in"],
        "edge_metrics":  [],
    },

    # ── Leave-one-out ablations
    "08_no_betweenness": {
        "description": "All metrics EXCEPT betweenness_centrality",
        "node_metrics": ["cyclomatic_complexity", "fan_out",
                         "loc", "param_count", "fan_in"],
        "edge_metrics":  ["cyclomatic_complexity", "loc", "fan_out"],
    },
    "09_no_cyclomatic": {
        "description": "All metrics EXCEPT cyclomatic_complexity",
        "node_metrics": ["betweenness_centrality", "fan_out",
                         "loc", "param_count", "fan_in"],
        "edge_metrics":  ["loc", "fan_out", "betweenness_centrality"],
    },
    "10_no_fan_out": {
        "description": "All metrics EXCEPT fan_out",
        "node_metrics": ["betweenness_centrality", "cyclomatic_complexity",
                         "loc", "param_count", "fan_in"],
        "edge_metrics":  ["cyclomatic_complexity", "loc", "betweenness_centrality"],
    },
    "11_no_loc": {
        "description": "All metrics EXCEPT loc",
        "node_metrics": ["betweenness_centrality", "cyclomatic_complexity",
                         "fan_out", "param_count", "fan_in"],
        "edge_metrics":  ["cyclomatic_complexity", "fan_out", "betweenness_centrality"],
    },
    "12_no_param_count": {
        "description": "All metrics EXCEPT param_count",
        "node_metrics": ["betweenness_centrality", "cyclomatic_complexity",
                         "fan_out", "loc", "fan_in"],
        "edge_metrics":  ["cyclomatic_complexity", "loc",
                          "fan_out", "betweenness_centrality"],
    },
    "13_no_fan_in": {
        "description": "All metrics EXCEPT fan_in",
        "node_metrics": ["betweenness_centrality", "cyclomatic_complexity",
                         "fan_out", "loc", "param_count"],
        "edge_metrics":  ["cyclomatic_complexity", "loc",
                          "fan_out", "betweenness_centrality"],
    },

    # ── Dimension group ablations
    "14_complexity_only_group": {
        "description": "Complexity dimension only: cyclomatic + betweenness",
        "node_metrics": ["cyclomatic_complexity", "betweenness_centrality"],
        "edge_metrics":  ["cyclomatic_complexity", "betweenness_centrality"],
    },
    "15_size_coupling_group": {
        "description": "Size + Coupling only: loc + fan_out + fan_in + param_count",
        "node_metrics": ["loc", "fan_out", "fan_in", "param_count"],
        "edge_metrics":  ["loc", "fan_out"],
    },
    "16_graph_metrics_only": {
        "description": "Graph structure metrics only: betweenness + fan_in + fan_out",
        "node_metrics": ["betweenness_centrality", "fan_in", "fan_out"],
        "edge_metrics":  ["betweenness_centrality", "fan_out"],
    },
    "17_source_metrics_only": {
        "description": "Source-text metrics only: cyclomatic + loc + param_count",
        "node_metrics": ["cyclomatic_complexity", "loc", "param_count"],
        "edge_metrics":  ["cyclomatic_complexity", "loc"],
    },

    # ── Original 4-metric baseline
    "18_original_4_metrics": {
        "description": "Original 4 metrics: cyclomatic + loc + param_count + fan_out",
        "node_metrics": ["cyclomatic_complexity", "loc", "param_count", "fan_out"],
        "edge_metrics":  ["cyclomatic_complexity", "loc", "fan_out"],
    },
}

# Color scheme for plots
CONFIG_COLORS = {
    "00_no_metrics":          "#2C3E50",
    "01_all_metrics":         "#2C3E50",
    "02_only_betweenness":    "#E67E22",
    "03_only_cyclomatic":     "#E67E22",
    "04_only_fan_out":        "#E67E22",
    "05_only_loc":            "#E67E22",
    "06_only_param_count":    "#E67E22",
    "07_only_fan_in":         "#E67E22",
    "08_no_betweenness":      "#E74C3C",
    "09_no_cyclomatic":       "#E74C3C",
    "10_no_fan_out":          "#E74C3C",
    "11_no_loc":              "#E74C3C",
    "12_no_param_count":      "#E74C3C",
    "13_no_fan_in":           "#E74C3C",
    "14_complexity_only_group":"#27AE60",
    "15_size_coupling_group": "#27AE60",
    "16_graph_metrics_only":  "#27AE60",
    "17_source_metrics_only": "#27AE60",
    "18_original_4_metrics":  "#8E44AD",
}


# ─────────────────────────────────────────────────────────────────────────────
# Data helpers
# ─────────────────────────────────────────────────────────────────────────────
def is_noise_method(mid: str) -> bool:
    return any(mid.endswith(p) for p in NOISE_PATTERNS)


def normalise_metrics(raw_metrics: dict, metric_names: list[str]) -> dict[str, dict[str, float]]:
    """
    Global min-max normalisation across all nodes for each requested metric.
    Returns {node_id: {metric: normalised_float}}.
    Computed fresh each call so each build_pyg_data_configurable call is independent.
    """
    result: dict[str, dict[str, float]] = {}
    # Compute min/max per metric
    bounds = {}
    for m in metric_names:
        vals = [v.get(m, 0.0) for v in raw_metrics.values()]
        lo, hi = min(vals), max(vals)
        bounds[m] = (lo, hi - lo if hi != lo else 1.0)

    for nid, entry in raw_metrics.items():
        result[nid] = {}
        for m in metric_names:
            lo, span = bounds[m]
            result[nid][m] = (entry.get(m, 0.0) - lo) / span
    return result


def build_edges_l3_local(tests, method_ids, g3):
    """No reverse edges at L3 — directional call graph."""
    edges = []
    for t in tests:
        tid   = t["test_id"]
        entry = t.get("entry_controller_method")
        if entry and entry in method_ids:
            edges.append((tid, entry, "TEST_RUNS_ON"))
        for rm in t.get("reachable_methods", []):
            mid = rm["method_id"]
            if mid in method_ids:
                edges.append((tid, mid, "TEST_COVERS"))
    for lnk in g3.get("links", []):
        rel = lnk.get("relation", "CALLS")
        src, tgt = lnk.get("source", ""), lnk.get("target", "")
        if src in method_ids and tgt in method_ids:
            edges.append((src, tgt, rel if rel in EDGE_TYPE_MAP else "CALLS"))
    return edges


def build_pyg_data_configurable(
    tests:        list,
    cover_field:  str,
    faulty_field: str,
    infra_ids:    set,
    infra_type:   str,
    edges_raw:    list,
    code_metrics: dict,        # raw unnormalised from code_metrics_full.json
    config:       dict,
):
    """
    Node features: 8 base + len(config['node_metrics']) metric values.
    Edge attributes: [edge_type_weight] + metric diffs for each edge metric.

    Returns: data, idx_map, all_ids, in_features, edge_dim
    """
    node_metric_names = config["node_metrics"]
    edge_metric_names = config["edge_metrics"]
    in_features = 8 + len(node_metric_names)
    edge_dim    = 1 + len(edge_metric_names)

    # Normalise all needed metrics once per call
    all_metric_names = list(set(node_metric_names) | set(edge_metric_names))
    norm_metrics = normalise_metrics(code_metrics, all_metric_names) if all_metric_names else {}

    ochiai, ef, ep = compute_ochiai(tests, cover_field)
    nf_total = max(sum(1 for t in tests if t["status"] == "FAILING"), 1)
    np_total = max(sum(1 for t in tests if t["status"] == "PASSING"), 1)

    faulty_nodes = {t[faulty_field] for t in tests if t.get(faulty_field)}
    test_ids     = {t["test_id"]     for t in tests}
    failing_ids  = {t["test_id"]     for t in tests if t["status"] == "FAILING"}

    all_ids = list(test_ids | infra_ids)
    idx_map = {nid: i for i, nid in enumerate(all_ids)}

    in_deg  = defaultdict(int)
    out_deg = defaultdict(int)
    for src, tgt, _ in edges_raw:
        in_deg[tgt]  += 1
        out_deg[src] += 1
    max_in  = max(in_deg.values(),  default=1)
    max_out = max(out_deg.values(), default=1)

    feats, labels = [], []
    for nid in all_ids:
        is_fail = 1.0 if nid in failing_ids else 0.0
        is_pass = 1.0 if (nid in test_ids and nid not in failing_ids) else 0.0
        is_inf  = 1.0 if nid in infra_ids else 0.0
        oc      = ochiai.get(nid, 0.0)
        n_ef    = ef.get(nid, 0) / nf_total
        n_ep    = ep.get(nid, 0) / np_total
        indeg   = in_deg.get(nid,  0) / max_in
        outdeg  = out_deg.get(nid, 0) / max_out
        base    = [is_fail, is_pass, is_inf, oc, n_ef, n_ep, indeg, outdeg]

        # Append node metric features (METHOD infra nodes only; 0.0 for others)
        if node_metric_names and nid in infra_ids and infra_type == "METHOD":
            node_m = norm_metrics.get(nid, {})
            metric_feat = [node_m.get(m, 0.0) for m in node_metric_names]
        else:
            metric_feat = [0.0] * len(node_metric_names)

        feats.append(base + metric_feat)
        labels.append(1.0 if (nid in faulty_nodes and nid in infra_ids) else 0.0)

    x = torch.tensor(feats,  dtype=torch.float)
    y = torch.tensor(labels, dtype=torch.float)

    # Build edges with (1 + len(edge_metric_names))-dim attributes
    edge_list, edge_attrs = [], []
    zero_m = {m: 0.0 for m in edge_metric_names}

    for src, tgt, etype in edges_raw:
        if src not in idx_map or tgt not in idx_map:
            continue
        w     = EDGE_TYPE_MAP.get(etype, EDGE_TYPE_MAP.get("DEFAULT", 0.5))
        src_m = norm_metrics.get(src, zero_m)
        tgt_m = norm_metrics.get(tgt, zero_m)
        diffs = [src_m.get(m, 0.0) - tgt_m.get(m, 0.0) for m in edge_metric_names]

        edge_list.append([idx_map[src], idx_map[tgt]])
        edge_attrs.append([w] + diffs)

    if edge_list:
        edge_index = torch.tensor(edge_list, dtype=torch.long).t().contiguous()
        edge_attr  = torch.tensor(edge_attrs, dtype=torch.float)
    else:
        edge_index = torch.zeros((2, 0), dtype=torch.long)
        edge_attr  = torch.zeros((0, edge_dim), dtype=torch.float)

    covered_set = {nid for t in tests for nid in t.get(cover_field, [])}
    train_set   = (covered_set | faulty_nodes) & infra_ids
    train_mask  = torch.tensor([nid in train_set for nid in all_ids])

    data = Data(x=x, y=y, edge_index=edge_index,
                edge_attr=edge_attr, train_mask=train_mask)
    return data, idx_map, all_ids, in_features, edge_dim


# ─────────────────────────────────────────────────────────────────────────────
# Flexible GAT model
# ─────────────────────────────────────────────────────────────────────────────
class FaultLocGAT_flexible(torch.nn.Module):
    """2-layer GAT accepting dynamic in_features and edge_dim."""
    def __init__(self, in_features: int, edge_dim: int,
                 hidden: int = HIDDEN, heads: int = HEADS, dropout: float = DROPOUT):
        super().__init__()
        self.conv1   = GATConv(in_features,    hidden,       heads=heads, edge_dim=edge_dim, dropout=dropout)
        self.conv2   = GATConv(hidden * heads, hidden,       heads=1,     edge_dim=edge_dim, dropout=dropout)
        self.out     = torch.nn.Linear(hidden, 1)
        self.dropout = dropout

    def forward(self, data):
        x, ei, ea = data.x, data.edge_index, data.edge_attr
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.elu(self.conv1(x, ei, ea))
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.elu(self.conv2(x, ei, ea))
        return self.out(x).squeeze(-1)   # raw logits — sigmoid applied at scoring


# ─────────────────────────────────────────────────────────────────────────────
# Training loop
# ─────────────────────────────────────────────────────────────────────────────
def run_one_seed(data, all_ids, method_ids, in_features, edge_dim,
                 epochs=EPOCHS, lr=LR):
    model = FaultLocGAT_flexible(in_features=in_features, edge_dim=edge_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    n_pos = max(data.y[data.train_mask].sum().item(), 1)
    n_neg = data.train_mask.sum().item() - n_pos
    pos_weight = torch.tensor([max(n_neg / n_pos, 1.0)])
    criterion  = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out  = model(data)
        loss = criterion(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

    model.eval()
    with torch.no_grad():
        logits = model(data)
        probs  = torch.sigmoid(logits).numpy()   # sigmoid only for scoring

    return {nid: float(probs[i]) for i, nid in enumerate(all_ids) if nid in method_ids}


# ─────────────────────────────────────────────────────────────────────────────
# Visualizations
# ─────────────────────────────────────────────────────────────────────────────
def plot1_top1_comparison(results: dict):
    sorted_cfgs = sorted(results.items(),
                         key=lambda x: x[1]["top1_mean"], reverse=True)
    names  = [c for c, _ in sorted_cfgs]
    means  = [r["top1_mean"]      for _, r in sorted_cfgs]
    stds   = [r["top1_std"]       for _, r in sorted_cfgs]
    colors = [CONFIG_COLORS.get(c, "#888") for c in names]

    baseline_mean  = results["00_no_metrics"]["top1_mean"]
    allmetric_mean = results["01_all_metrics"]["top1_mean"]

    fig, ax = plt.subplots(figsize=(14, 9), dpi=150)
    y_pos = range(len(names))
    bars = ax.barh(list(y_pos), means, xerr=stds, color=colors,
                   edgecolor="white", height=0.7, capsize=4)
    ax.axvline(baseline_mean,  color="#2C3E50", linestyle="--", linewidth=1.5,
               label=f"00_no_metrics ({baseline_mean:.1%})")
    ax.axvline(allmetric_mean, color="#27AE60", linestyle=":",  linewidth=1.5,
               label=f"01_all_metrics ({allmetric_mean:.1%})")
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(names, fontsize=9)
    ax.set_xlabel("Top-1 Accuracy (mean over 10 seeds)", fontsize=11)
    ax.set_title("Ablation Study: Top-1 Accuracy by Metric Configuration\n(10 seeds, mean ± std)",
                 fontsize=12, fontweight="bold")

    legend_patches = [
        mpatches.Patch(color="#2C3E50", label="Baseline configs"),
        mpatches.Patch(color="#E67E22", label="Single metric"),
        mpatches.Patch(color="#E74C3C", label="Leave-one-out"),
        mpatches.Patch(color="#27AE60", label="Dimension group"),
        mpatches.Patch(color="#8E44AD", label="Original 4 metrics"),
    ]
    ax.legend(handles=legend_patches, loc="lower right", fontsize=9)
    ax.set_xlim(0, 1.05)
    for i, (m, s) in enumerate(zip(means, stds)):
        ax.text(m + s + 0.01, i, f"{m:.1%}", va="center", fontsize=8)
    ax.legend(handles=legend_patches +
              [plt.Line2D([0], [0], color="#2C3E50", ls="--", label=f"Baseline ({baseline_mean:.1%})"),
               plt.Line2D([0], [0], color="#27AE60", ls=":",  label=f"All metrics ({allmetric_mean:.1%})")],
              loc="lower right", fontsize=8)
    plt.tight_layout()
    path = PLOTS_DIR / "ablation_top1_comparison.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot2_loo_impact(results: dict):
    all_mean = results["01_all_metrics"]["top1_mean"]
    LOO_MAP  = {
        "betweenness_centrality": "08_no_betweenness",
        "cyclomatic_complexity":  "09_no_cyclomatic",
        "fan_out":                "10_no_fan_out",
        "loc":                    "11_no_loc",
        "param_count":            "12_no_param_count",
        "fan_in":                 "13_no_fan_in",
    }
    metrics = list(LOO_MAP.keys())
    deltas  = [results[LOO_MAP[m]]["top1_mean"] - all_mean for m in metrics]
    stds    = [results[LOO_MAP[m]]["top1_std"]              for m in metrics]
    defA    = [DEFA_DELTA[m] for m in metrics]

    # Sort by |delta|
    order   = sorted(range(len(metrics)), key=lambda i: abs(deltas[i]), reverse=True)
    metrics_s = [metrics[i] for i in order]
    deltas_s  = [deltas[i]  for i in order]
    stds_s    = [stds[i]    for i in order]
    defA_s    = [defA[i]    for i in order]

    colors = ["#E74C3C" if d < 0 else "#27AE60" for d in deltas_s]
    fig, ax1 = plt.subplots(figsize=(11, 6), dpi=150)
    y_pos = range(len(metrics_s))
    ax1.barh(list(y_pos), deltas_s, xerr=stds_s, color=colors,
             edgecolor="white", height=0.6, capsize=4)
    ax1.axvline(0, color="black", linewidth=1)
    ax1.set_yticks(list(y_pos))
    ax1.set_yticklabels(metrics_s, fontsize=10)
    ax1.set_xlabel("ΔTop-1 vs 01_all_metrics (negative = removing this metric hurts)", fontsize=10)
    ax1.set_title("Leave-One-Out: Accuracy Impact of Each Metric", fontsize=12, fontweight="bold")

    # Secondary x-axis: Definition A delta
    ax2 = ax1.twiny()
    ax2.set_xlim(ax1.get_xlim())  # same scale — just for annotation
    for i, (m, da) in enumerate(zip(metrics_s, defA_s)):
        ax1.text(0.002, i + 0.28, f"DefA δ={da:.3f}", fontsize=7.5, color="#555", va="center")
    ax2.set_visible(False)

    plt.tight_layout()
    path = PLOTS_DIR / "ablation_loo_impact.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot3_seed_variance(results: dict):
    config_names  = list(results.keys())
    all_seed_data = [results[c]["all_top1_seeds"] for c in config_names]
    colors        = [CONFIG_COLORS.get(c, "#888") for c in config_names]

    fig, ax = plt.subplots(figsize=(16, 8), dpi=150)
    bp = ax.boxplot(all_seed_data, vert=True, patch_artist=True,
                    medianprops={"color": "black", "linewidth": 2},
                    flierprops={"marker": "o", "markersize": 4, "alpha": 0.5})
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.8)
    ax.set_xticks(range(1, len(config_names) + 1))
    ax.set_xticklabels(config_names, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Top-1 Accuracy", fontsize=11)
    ax.set_ylim(-0.05, 1.05)
    ax.set_title("Top-1 Score Distribution Across 10 Seeds per Configuration",
                 fontsize=12, fontweight="bold")
    ax.grid(axis="y", alpha=0.3)

    legend_patches = [
        mpatches.Patch(color="#2C3E50", label="Baseline"),
        mpatches.Patch(color="#E67E22", label="Single metric"),
        mpatches.Patch(color="#E74C3C", label="Leave-one-out"),
        mpatches.Patch(color="#27AE60", label="Group"),
        mpatches.Patch(color="#8E44AD", label="Original 4"),
    ]
    ax.legend(handles=legend_patches, loc="lower right", fontsize=9)
    plt.tight_layout()
    path = PLOTS_DIR / "ablation_seed_variance.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot4_defa_vs_ablation(results: dict):
    LOO_MAP = {
        "betweenness_centrality": "08_no_betweenness",
        "cyclomatic_complexity":  "09_no_cyclomatic",
        "fan_out":                "10_no_fan_out",
        "loc":                    "11_no_loc",
        "param_count":            "12_no_param_count",
        "fan_in":                 "13_no_fan_in",
    }
    all_mean = results["01_all_metrics"]["top1_mean"]
    metrics  = list(LOO_MAP.keys())
    defa_x   = [DEFA_DELTA[m]                                       for m in metrics]
    impact_y = [abs(results[LOO_MAP[m]]["top1_mean"] - all_mean)    for m in metrics]

    fig, ax = plt.subplots(figsize=(9, 7), dpi=150)
    ax.scatter(defa_x, impact_y, color="#E74C3C", s=120, zorder=5)

    # Labels
    for m, x, y in zip(metrics, defa_x, impact_y):
        ax.annotate(m.replace("_", "\n"), (x, y),
                    textcoords="offset points", xytext=(7, 4), fontsize=8)

    # Linear regression line
    if len(metrics) > 2:
        from scipy.stats import linregress
        slope, intercept, rval, pval, _ = linregress(defa_x, impact_y)
        xs = np.linspace(min(defa_x) - 0.05, max(defa_x) + 0.05, 100)
        ax.plot(xs, slope * xs + intercept, color="gray", linestyle="--", linewidth=1.5)

        corr, pv = spearmanr(defa_x, impact_y)
        ax.text(0.05, 0.92,
                f"Spearman r = {corr:.3f}\np = {pv:.3f}",
                transform=ax.transAxes, fontsize=10,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.8))

    ax.set_xlabel("Definition A Cliff's Delta (statistical fault correlation)", fontsize=11)
    ax.set_ylabel("|ΔTop-1| when metric removed (GNN contribution)", fontsize=11)
    ax.set_title("Definition A Statistical Importance vs Ablation GNN Contribution",
                 fontsize=12, fontweight="bold")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    path = PLOTS_DIR / "ablation_defA_vs_ablation.png"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 70)
    print("ABLATION STUDY — GAT GNN Metric Contribution Analysis")
    print(f"Configs: {len(CONFIGS)}  |  Seeds: {N_SEEDS}  |  Epochs: {EPOCHS}")
    print("=" * 70)

    # ── Load data ----------------------------------------------------------------
    print(f"\nLoading graph from: {GRAPH_PATH}")
    with open(GRAPH_PATH) as f: g3 = json.load(f)
    with open(TESTS_PATH)  as f: tests = json.load(f)
    with open(METRICS_PATH) as f: raw_code_metrics = json.load(f)

    method_ids_raw = {n["id"] for n in g3["nodes"] if n.get("type") == "METHOD"}
    method_ids     = {m for m in method_ids_raw if not is_noise_method(m)}
    print(f"METHOD nodes: {len(method_ids_raw)} → {len(method_ids)} (after noise exclusion)")

    edges_raw = build_edges_l3_local(tests, method_ids, g3)
    print(f"L3 edges: {len(edges_raw)}")

    faulty_nodes = {t["faulty_method"] for t in tests if t.get("faulty_method")}
    print(f"Faulty nodes: {len(faulty_nodes & method_ids)}/{len(faulty_nodes)}")

    # ── Estimate runtime ---------------------------------------------------------
    print("\nEstimating runtime from one seed of 00_no_metrics...")
    t0 = time.time()
    torch.manual_seed(0); np.random.seed(0); random.seed(0)
    _d, _, _ids, _inf, _edim = build_pyg_data_configurable(
        tests, "method_path", "faulty_method",
        method_ids, "METHOD", edges_raw, raw_code_metrics,
        CONFIGS["00_no_metrics"],
    )
    run_one_seed(_d, _ids, method_ids, _inf, _edim)
    t_one = time.time() - t0
    est_total = t_one * len(CONFIGS) * N_SEEDS / 60
    print(f"One seed took {t_one:.1f}s → estimated total: ~{est_total:.0f} minutes")

    # ── Run all configurations ---------------------------------------------------
    results: dict = {}
    PARTIAL_PATH = OUTPUT_DIR / "ablation_results_partial.json"

    for cfg_idx, (config_name, config) in enumerate(CONFIGS.items(), 1):
        print(f"\n[{cfg_idx:02d}/{len(CONFIGS)}] {config_name}  —  {config['description']}")
        t_cfg_start = time.time()

        top1_scores, top3_scores, top5_scores = [], [], []

        for seed in range(N_SEEDS):
            torch.manual_seed(seed)
            np.random.seed(seed)
            random.seed(seed)

            data, idx_map, all_ids, in_features, edge_dim = build_pyg_data_configurable(
                tests, "method_path", "faulty_method",
                method_ids, "METHOD", edges_raw,
                raw_code_metrics, config,
            )

            scores_dict = run_one_seed(data, all_ids, method_ids, in_features, edge_dim)
            acc, _, _   = top_k_accuracy(tests, "method_path", "faulty_method", scores_dict)

            top1_scores.append(acc[1])
            top3_scores.append(acc[3])
            top5_scores.append(acc[5])
            print(f"  seed {seed+1:2d}/{N_SEEDS}  Top-1={acc[1]:.1%}", end="\r")

        elapsed = time.time() - t_cfg_start
        print(f"  ✓  Top-1: {np.mean(top1_scores):.1%} ± {np.std(top1_scores):.1%}"
              f"   Top-3: {np.mean(top3_scores):.1%}"
              f"   Top-5: {np.mean(top5_scores):.1%}"
              f"   ({elapsed:.0f}s)")

        results[config_name] = {
            "description":     config["description"],
            "node_metrics":    config["node_metrics"],
            "edge_metrics":    config["edge_metrics"],
            "in_features":     in_features,
            "edge_dim":        edge_dim,
            "top1_mean":       float(np.mean(top1_scores)),
            "top1_std":        float(np.std(top1_scores)),
            "top1_min":        float(np.min(top1_scores)),
            "top1_max":        float(np.max(top1_scores)),
            "top3_mean":       float(np.mean(top3_scores)),
            "top3_std":        float(np.std(top3_scores)),
            "top5_mean":       float(np.mean(top5_scores)),
            "top5_std":        float(np.std(top5_scores)),
            "all_top1_seeds":  top1_scores,
        }

        # Incremental save
        with open(PARTIAL_PATH, "w") as f:
            json.dump(results, f, indent=2)

    # ── TABLE 1: All results sorted by Top-1 ------------------------------------
    print("\n" + "=" * 90)
    print("=== ABLATION STUDY RESULTS — Sorted by Top-1 Mean ===")
    print("=" * 90)
    baseline_mean = results["00_no_metrics"]["top1_mean"]
    sorted_res = sorted(results.items(), key=lambda x: x[1]["top1_mean"], reverse=True)
    hdr = (f"{'Rank':>4}  {'Config':<28} {'in_f':>5} {'edim':>5}  "
           f"{'Top-1 mean±std':>18}  {'Top-3':>7}  {'Top-5':>7}  {'Δ baseline':>10}")
    print(hdr)
    print("-" * len(hdr))
    for rank, (cname, r) in enumerate(sorted_res, 1):
        delta = r["top1_mean"] - baseline_mean
        print(f"{rank:>4}  {cname:<28} {r['in_features']:>5} {r['edge_dim']:>5}  "
              f"{r['top1_mean']:>7.1%} ± {r['top1_std']:>5.1%}  "
              f"{r['top3_mean']:>7.1%}  {r['top5_mean']:>7.1%}  "
              f"{delta:>+9.1%}")

    # ── TABLE 2: Leave-one-out impact -------------------------------------------
    print("\n" + "=" * 75)
    print("=== LEAVE-ONE-OUT: Impact of Removing Each Metric ===")
    print("(Negative Δ = removing this metric HURTS accuracy)")
    print("=" * 75)
    all_mean = results["01_all_metrics"]["top1_mean"]
    LOO_MAP  = {
        "betweenness_centrality": "08_no_betweenness",
        "cyclomatic_complexity":  "09_no_cyclomatic",
        "fan_out":                "10_no_fan_out",
        "loc":                    "11_no_loc",
        "param_count":            "12_no_param_count",
        "fan_in":                 "13_no_fan_in",
    }
    print(f"{'Metric removed':<26} {'Top-1 (without)':>17}  {'Δ vs all_metrics':>17}  {'DefA rank':>10}")
    print("-" * 76)
    loo_impacts = {}
    for m, cfg in LOO_MAP.items():
        r = results[cfg]
        delta = r["top1_mean"] - all_mean
        loo_impacts[m] = delta
        print(f"{m:<26} {r['top1_mean']:>7.1%} ± {r['top1_std']:>5.1%}  "
              f"{delta:>+16.1%}  {DEFA_RANK[m]:>10}")
    most_impactful  = min(loo_impacts, key=loo_impacts.get)
    least_impactful = max(loo_impacts, key=loo_impacts.get)
    print(f"\nMost  impactful (largest drop when removed) : {most_impactful}")
    print(f"Least impactful (smallest drop when removed): {least_impactful}")

    # ── TABLE 3: Dimension group comparison -------------------------------------
    print("\n" + "=" * 75)
    print("=== DIMENSION GROUP COMPARISON ===")
    print("=" * 75)
    GROUP_CONFIGS = [
        ("16_graph_metrics_only",  "betweenness + fan_in + fan_out"),
        ("14_complexity_only_group","cyclomatic + betweenness"),
        ("17_source_metrics_only", "cyclomatic + loc + param"),
        ("15_size_coupling_group", "loc + fan_out + fan_in + param"),
        ("18_original_4_metrics",  "cyclomatic + loc + param + fanout"),
        ("01_all_metrics",         "all 6"),
    ]
    print(f"{'Group':<28} {'Metrics included':<38} {'Top-1':>7}  {'Δ no_metrics':>13}")
    print("-" * 92)
    for cfg, desc in GROUP_CONFIGS:
        r = results[cfg]
        delta = r["top1_mean"] - baseline_mean
        print(f"{cfg:<28} {desc:<38} {r['top1_mean']:>7.1%}  {delta:>+12.1%}")

    # ── STEP 6: Spearman correlation -------------------------------------------
    print("\n" + "=" * 60)
    print("=== Definition A vs Ablation Rank Correlation ===")
    defa_deltas = [DEFA_DELTA[m] for m in LOO_MAP]
    loo_delta_vals = [abs(loo_impacts[m]) for m in LOO_MAP]
    # Rank by LOO impact (largest impact = rank 1)
    loo_order = sorted(range(len(LOO_MAP)), key=lambda i: loo_delta_vals[i], reverse=True)
    loo_ranks = [0] * len(LOO_MAP)
    for rank_pos, orig_idx in enumerate(loo_order, 1):
        loo_ranks[orig_idx] = rank_pos
    defa_ranks_vals = [DEFA_RANK[m] for m in LOO_MAP]

    corr, pval = spearmanr(defa_ranks_vals, loo_ranks)
    print(f"\nSpearman r = {corr:.3f}  (p = {pval:.3f})")
    print(f"  Definition A metric ranks (by Cliff's delta): {list(zip(LOO_MAP.keys(), defa_ranks_vals))}")
    print(f"  Ablation LOO impact ranks (1=most impactful): {list(zip(LOO_MAP.keys(), loo_ranks))}")
    if corr > 0.7:
        msg = "Strong agreement: statistical correlation predicts GNN contribution"
    elif corr > 0.4:
        msg = "Moderate agreement: statistical correlation partially predicts GNN contribution"
    else:
        msg = ("Weak agreement: statistical correlation does NOT predict GNN contribution.\n"
               "  → Graph propagation changes which metrics matter. BOTH analyses needed.")
    print(f"\n  {msg}")

    # ── Save final results -------------------------------------------------------
    final_path = OUTPUT_DIR / "ablation_results.json"
    with open(final_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved results to {final_path}")

    # ── Plots -------------------------------------------------------------------
    print("\nGenerating plots...")
    try:
        plot1_top1_comparison(results)
    except Exception as e:
        print(f"  Plot 1 failed: {e}")
    try:
        plot2_loo_impact(results)
    except Exception as e:
        print(f"  Plot 2 failed: {e}")
    try:
        plot3_seed_variance(results)
    except Exception as e:
        print(f"  Plot 3 failed: {e}")
    try:
        plot4_defa_vs_ablation(results)
    except Exception as e:
        print(f"  Plot 4 failed: {e}")

    # ── Final summary -----------------------------------------------------------
    best_name, best_res = sorted_res[0]
    print(f"\nAblation complete: {len(CONFIGS)} configs × {N_SEEDS} seeds. "
          f"Best config: {best_name} with Top-1={best_res['top1_mean']:.1%}. "
          f"Results saved to {final_path}")


if __name__ == "__main__":
    main()
